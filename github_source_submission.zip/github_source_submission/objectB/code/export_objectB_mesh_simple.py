import argparse
import os
import sys
from pathlib import Path

import mcubes
import numpy as np
import torch
import trimesh
from omegaconf import OmegaConf


def load_geometry(run_dir: Path, device: torch.device):
    sys.path.insert(0, str(Path("threestudio").resolve()))
    import threestudio

    cfg = OmegaConf.load(run_dir / "configs" / "parsed.yaml")
    geometry = threestudio.find(cfg.system.geometry_type)(cfg.system.geometry)
    ckpt = torch.load(run_dir / "ckpts" / "last.ckpt", map_location="cpu")
    geometry_state = {
        key.removeprefix("geometry."): value
        for key, value in ckpt["state_dict"].items()
        if key.startswith("geometry.")
    }
    geometry.load_state_dict(geometry_state, strict=False)
    geometry.to(device)
    geometry.eval()
    return geometry, cfg


@torch.no_grad()
def sample_density(geometry, radius: float, resolution: int, chunk: int) -> np.ndarray:
    lin = torch.linspace(-radius, radius, resolution, device=geometry.bbox.device)
    grid_x, grid_y, grid_z = torch.meshgrid(lin, lin, lin, indexing="ij")
    points = torch.stack([grid_x, grid_y, grid_z], dim=-1).reshape(-1, 3)
    densities = []
    for start in range(0, points.shape[0], chunk):
        density = geometry.forward_density(points[start : start + chunk])
        densities.append(density.detach().float().cpu())
    return torch.cat(densities, dim=0).reshape(resolution, resolution, resolution).numpy()


@torch.no_grad()
def sample_vertex_colors(geometry, vertices: np.ndarray, chunk: int) -> np.ndarray:
    device = geometry.bbox.device
    verts = torch.from_numpy(vertices).float().to(device)
    colors = []
    for start in range(0, verts.shape[0], chunk):
        out = geometry.export(verts[start : start + chunk])
        if "features" not in out:
            colors.append(torch.full((verts[start : start + chunk].shape[0], 3), 0.15))
            continue
        colors.append(torch.sigmoid(out["features"]).detach().float().cpu())
    color = torch.cat(colors, dim=0).numpy()
    return np.clip(color * 255.0, 0, 255).astype(np.uint8)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--output", default=None)
    parser.add_argument("--resolution", type=int, default=96)
    parser.add_argument("--threshold", type=float, default=1.0)
    parser.add_argument("--chunk", type=int, default=131072)
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    output = Path(args.output) if args.output else run_dir / "save" / "objectB_phone_mesh.ply"
    output.parent.mkdir(parents=True, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    geometry, cfg = load_geometry(run_dir, device)
    radius = float(cfg.system.geometry.radius)

    density = sample_density(geometry, radius, args.resolution, args.chunk)
    print(
        "density",
        "min",
        float(density.min()),
        "max",
        float(density.max()),
        "threshold",
        args.threshold,
    )
    vertices, faces = mcubes.marching_cubes(density, args.threshold)
    vertices = vertices / (args.resolution - 1) * (2.0 * radius) - radius
    colors = sample_vertex_colors(geometry, vertices.astype(np.float32), args.chunk)

    mesh = trimesh.Trimesh(
        vertices=vertices,
        faces=faces,
        vertex_colors=colors,
        process=False,
    )
    mesh.export(output)
    print("saved", output, "vertices", len(mesh.vertices), "faces", len(mesh.faces))


if __name__ == "__main__":
    main()
