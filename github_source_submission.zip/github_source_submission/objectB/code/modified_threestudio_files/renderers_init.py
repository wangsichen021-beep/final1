import importlib

import threestudio

for module in [
    "base",
    "deferred_volume_renderer",
    "gan_volume_renderer",
    "nerf_volume_renderer",
    "neus_volume_renderer",
    "nvdiff_rasterizer",
    "patch_renderer",
    "simple_volume_renderer",
]:
    try:
        importlib.import_module(f"{__name__}.{module}")
    except ImportError as exc:
        threestudio.warn(f"Skip optional renderer module {module}: {exc}")
