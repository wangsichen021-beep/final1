import importlib

import threestudio

for module in ["base", "mesh_exporter"]:
    try:
        importlib.import_module(f"{__name__}.{module}")
    except ImportError as exc:
        threestudio.warn(f"Skip optional exporter module {module}: {exc}")
