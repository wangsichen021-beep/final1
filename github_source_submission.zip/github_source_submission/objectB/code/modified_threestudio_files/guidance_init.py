import importlib

import threestudio

for module in [
    "controlnet_guidance",
    "deep_floyd_guidance",
    "instructpix2pix_guidance",
    "stable_diffusion_guidance",
    "stable_diffusion_sdi_guidance",
    "stable_diffusion_unified_guidance",
    "stable_diffusion_vsd_guidance",
    "stable_zero123_guidance",
    "zero123_guidance",
    "zero123_unified_guidance",
]:
    try:
        importlib.import_module(f"{__name__}.{module}")
    except ImportError as exc:
        threestudio.warn(f"Skip optional guidance module {module}: {exc}")
