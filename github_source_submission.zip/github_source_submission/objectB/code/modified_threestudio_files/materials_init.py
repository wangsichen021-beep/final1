import importlib

import threestudio

for module in [
    "base",
    "diffuse_with_point_light_material",
    "hybrid_rgb_latent_material",
    "neural_radiance_material",
    "no_material",
    "pbr_material",
    "sd_latent_adapter_material",
]:
    try:
        importlib.import_module(f"{__name__}.{module}")
    except ImportError as exc:
        threestudio.warn(f"Skip optional material module {module}: {exc}")
