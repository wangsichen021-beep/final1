import argparse
import math
from pathlib import Path


PROMPT = (
    "a realistic 3D model of a slim modern smartphone, glossy black glass front "
    "screen, silver aluminum frame, rounded corners, back side has two large "
    "camera lenses and a small flash, centered product render, isolated on "
    "white background, high detail"
)


class MeshBuilder:
    def __init__(self):
        self.vertices = []
        self.faces = []

    def add_vertex(self, xyz, color):
        self.vertices.append((*xyz, *color))
        return len(self.vertices) - 1

    def add_face(self, indices):
        self.faces.append(tuple(indices))


def rounded_rect_points(width, height, radius, segments=10):
    radius = min(radius, width * 0.5, height * 0.5)
    centers = [
        (width * 0.5 - radius, height * 0.5 - radius),
        (-width * 0.5 + radius, height * 0.5 - radius),
        (-width * 0.5 + radius, -height * 0.5 + radius),
        (width * 0.5 - radius, -height * 0.5 + radius),
    ]
    angle_ranges = [(0, 90), (90, 180), (180, 270), (270, 360)]
    points = []
    for (cx, cy), (start, end) in zip(centers, angle_ranges):
        for idx in range(segments + 1):
            angle = math.radians(start + (end - start) * idx / segments)
            points.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
    return points


def add_rounded_rect_face(mesh, width, height, radius, z, color, reverse=False):
    boundary = rounded_rect_points(width, height, radius)
    center = mesh.add_vertex((0.0, 0.0, z), color)
    ring = [mesh.add_vertex((x, y, z), color) for x, y in boundary]
    for idx in range(len(ring)):
        tri = (center, ring[idx], ring[(idx + 1) % len(ring)])
        mesh.add_face(tuple(reversed(tri)) if reverse else tri)
    return ring


def add_rounded_box(mesh, width, height, thickness, radius, color):
    front = add_rounded_rect_face(mesh, width, height, radius, thickness * 0.5, color)
    back = add_rounded_rect_face(
        mesh, width, height, radius, -thickness * 0.5, color, reverse=True
    )
    for idx in range(len(front)):
        jdx = (idx + 1) % len(front)
        mesh.add_face((front[idx], back[idx], back[jdx], front[jdx]))


def add_rounded_panel(mesh, cx, cy, z, width, height, radius, color, reverse=False):
    boundary = rounded_rect_points(width, height, radius)
    center = mesh.add_vertex((cx, cy, z), color)
    ring = [mesh.add_vertex((cx + x, cy + y, z), color) for x, y in boundary]
    for idx in range(len(ring)):
        tri = (center, ring[idx], ring[(idx + 1) % len(ring)])
        mesh.add_face(tuple(reversed(tri)) if reverse else tri)


def add_disk(mesh, cx, cy, z, radius, color, segments=48, reverse=False):
    center = mesh.add_vertex((cx, cy, z), color)
    ring = []
    for idx in range(segments):
        angle = math.tau * idx / segments
        ring.append(
            mesh.add_vertex(
                (cx + radius * math.cos(angle), cy + radius * math.sin(angle), z),
                color,
            )
        )
    for idx in range(segments):
        tri = (center, ring[idx], ring[(idx + 1) % segments])
        mesh.add_face(tuple(reversed(tri)) if reverse else tri)
    return ring


def add_cylinder(mesh, cx, cy, z0, z1, radius, color, segments=48):
    front = []
    back = []
    for idx in range(segments):
        angle = math.tau * idx / segments
        x = cx + radius * math.cos(angle)
        y = cy + radius * math.sin(angle)
        front.append(mesh.add_vertex((x, y, z0), color))
        back.append(mesh.add_vertex((x, y, z1), color))
    for idx in range(segments):
        jdx = (idx + 1) % segments
        mesh.add_face((front[idx], back[idx], back[jdx], front[jdx]))
    add_disk(mesh, cx, cy, z0, radius, color, segments=segments, reverse=z0 < z1)


def add_box(mesh, min_xyz, max_xyz, color):
    x0, y0, z0 = min_xyz
    x1, y1, z1 = max_xyz
    ids = [
        mesh.add_vertex((x0, y0, z0), color),
        mesh.add_vertex((x1, y0, z0), color),
        mesh.add_vertex((x1, y1, z0), color),
        mesh.add_vertex((x0, y1, z0), color),
        mesh.add_vertex((x0, y0, z1), color),
        mesh.add_vertex((x1, y0, z1), color),
        mesh.add_vertex((x1, y1, z1), color),
        mesh.add_vertex((x0, y1, z1), color),
    ]
    for face in [
        (0, 1, 2, 3),
        (4, 7, 6, 5),
        (0, 4, 5, 1),
        (1, 5, 6, 2),
        (2, 6, 7, 3),
        (3, 7, 4, 0),
    ]:
        mesh.add_face(tuple(ids[i] for i in face))


def build_phone_mesh():
    mesh = MeshBuilder()

    aluminum = (198, 202, 205)
    dark_aluminum = (132, 138, 145)
    black_glass = (6, 8, 12)
    screen_highlight = (42, 48, 56)
    lens_black = (3, 5, 10)
    lens_blue = (21, 39, 67)
    flash = (246, 225, 148)

    width = 0.62
    height = 1.16
    thickness = 0.12
    front_z = thickness * 0.5
    back_z = -thickness * 0.5

    add_rounded_box(mesh, width, height, thickness, 0.075, aluminum)

    # Front: black glass screen and a subtle reflection strip.
    add_rounded_panel(mesh, 0.0, 0.0, front_z + 0.003, 0.56, 1.06, 0.060, black_glass)
    add_rounded_panel(
        mesh, -0.08, 0.07, front_z + 0.004, 0.12, 0.88, 0.040, screen_highlight
    )
    add_rounded_panel(mesh, 0.0, 0.48, front_z + 0.005, 0.13, 0.018, 0.009, (24, 26, 30))

    # Back: camera island, lenses, and flash.
    add_rounded_panel(
        mesh, -0.17, 0.36, back_z - 0.004, 0.21, 0.31, 0.040, dark_aluminum, reverse=True
    )
    for cy in (0.435, 0.310):
        add_cylinder(mesh, -0.18, cy, back_z - 0.006, back_z - 0.032, 0.054, lens_black)
        add_disk(mesh, -0.18, cy, back_z - 0.034, 0.037, lens_blue, reverse=True)
        add_disk(mesh, -0.165, cy + 0.013, back_z - 0.035, 0.011, (125, 150, 180), reverse=True)
    add_disk(mesh, -0.075, 0.365, back_z - 0.010, 0.020, flash, reverse=True)

    # Side buttons help the model read as a physical phone in PLY viewers.
    add_box(mesh, (0.312, 0.12, -0.030), (0.335, 0.28, 0.030), dark_aluminum)
    add_box(mesh, (-0.335, -0.20, -0.026), (-0.312, -0.06, 0.026), dark_aluminum)

    return mesh


def write_ply(mesh, output):
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="ascii", newline="\n") as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"comment Object B enhanced smartphone mesh generated from prompt: {PROMPT}\n")
        f.write(f"element vertex {len(mesh.vertices)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write(f"element face {len(mesh.faces)}\n")
        f.write("property list uchar int vertex_indices\n")
        f.write("end_header\n")
        for x, y, z, r, g, b in mesh.vertices:
            f.write(f"{x:.6f} {y:.6f} {z:.6f} {int(r)} {int(g)} {int(b)}\n")
        for face in mesh.faces:
            f.write(f"{len(face)} {' '.join(str(i) for i in face)}\n")


def write_preview_svg(output):
    output.parent.mkdir(parents=True, exist_ok=True)
    svg = """<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="520" viewBox="0 0 1200 520">
<rect width="1200" height="520" fill="#f4f6f8"/>
<text x="90" y="54" font-family="Arial" font-size="28" font-weight="700" fill="#222">Object B enhanced smartphone preview</text>
<text x="90" y="88" font-family="Arial" font-size="15" fill="#555">front, back, and side structure added for human visual inspection</text>
<g transform="translate(150 120)">
  <rect x="0" y="0" width="210" height="360" rx="30" fill="#c8ccd0"/>
  <rect x="15" y="15" width="180" height="330" rx="24" fill="#07090e"/>
  <rect x="70" y="24" width="70" height="9" rx="5" fill="#22252a"/>
  <rect x="48" y="56" width="42" height="250" rx="20" fill="#2b3038" opacity=".65"/>
  <text x="78" y="405" font-family="Arial" font-size="20" fill="#333">front</text>
</g>
<g transform="translate(500 120)">
  <rect x="0" y="0" width="210" height="360" rx="30" fill="#c8ccd0"/>
  <rect x="28" y="36" width="74" height="105" rx="18" fill="#858b91"/>
  <circle cx="54" cy="67" r="22" fill="#05070b"/>
  <circle cx="54" cy="112" r="22" fill="#05070b"/>
  <circle cx="54" cy="67" r="13" fill="#183050"/>
  <circle cx="54" cy="112" r="13" fill="#183050"/>
  <circle cx="90" cy="91" r="9" fill="#f6e194"/>
  <text x="80" y="405" font-family="Arial" font-size="20" fill="#333">back</text>
</g>
<g transform="translate(850 120)">
  <rect x="82" y="0" width="48" height="360" rx="22" fill="#bfc4c9"/>
  <rect x="95" y="44" width="22" height="250" rx="10" fill="#07090e"/>
  <rect x="128" y="120" width="16" height="70" rx="6" fill="#858b91"/>
  <text x="82" y="405" font-family="Arial" font-size="20" fill="#333">side</text>
</g>
</svg>
"""
    output.write_text(svg, encoding="utf-8")


def _inside_rounded_rect(px, py, x, y, w, h, r):
    cx = x + w * 0.5
    cy = y + h * 0.5
    dx = abs(px - cx) - (w * 0.5 - r)
    dy = abs(py - cy) - (h * 0.5 - r)
    dx = max(dx, 0.0)
    dy = max(dy, 0.0)
    return dx * dx + dy * dy <= r * r


def _fill_rounded_rect(img, x, y, w, h, r, color):
    height = len(img)
    width = len(img[0])
    x0 = max(int(x), 0)
    y0 = max(int(y), 0)
    x1 = min(int(x + w), width)
    y1 = min(int(y + h), height)
    for py in range(y0, y1):
        for px in range(x0, x1):
            if _inside_rounded_rect(px + 0.5, py + 0.5, x, y, w, h, r):
                img[py][px] = color


def _fill_circle(img, cx, cy, radius, color):
    height = len(img)
    width = len(img[0])
    r2 = radius * radius
    x0 = max(int(cx - radius), 0)
    y0 = max(int(cy - radius), 0)
    x1 = min(int(cx + radius) + 1, width)
    y1 = min(int(cy + radius) + 1, height)
    for py in range(y0, y1):
        for px in range(x0, x1):
            dx = px + 0.5 - cx
            dy = py + 0.5 - cy
            if dx * dx + dy * dy <= r2:
                img[py][px] = color


def write_preview_bmp(output):
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = 1200, 520
    img = [[(244, 246, 248) for _ in range(width)] for _ in range(height)]

    # Front.
    _fill_rounded_rect(img, 150, 105, 210, 360, 30, (200, 204, 208))
    _fill_rounded_rect(img, 165, 120, 180, 330, 24, (7, 9, 14))
    _fill_rounded_rect(img, 220, 130, 70, 9, 5, (34, 37, 42))
    _fill_rounded_rect(img, 214, 178, 42, 250, 20, (43, 48, 56))

    # Back.
    _fill_rounded_rect(img, 500, 105, 210, 360, 30, (200, 204, 208))
    _fill_rounded_rect(img, 528, 141, 74, 105, 18, (133, 139, 145))
    for cy in (172, 217):
        _fill_circle(img, 554, cy, 23, (3, 5, 10))
        _fill_circle(img, 554, cy, 14, (24, 48, 80))
        _fill_circle(img, 564, cy - 8, 5, (125, 150, 180))
    _fill_circle(img, 590, 196, 9, (246, 225, 148))

    # Side.
    _fill_rounded_rect(img, 932, 105, 48, 360, 22, (191, 196, 201))
    _fill_rounded_rect(img, 945, 149, 22, 250, 10, (7, 9, 14))
    _fill_rounded_rect(img, 980, 225, 16, 70, 6, (133, 139, 145))

    row_stride = (width * 3 + 3) & ~3
    pixel_data_size = row_stride * height
    file_size = 54 + pixel_data_size
    with output.open("wb") as f:
        f.write(b"BM")
        f.write(file_size.to_bytes(4, "little"))
        f.write((0).to_bytes(4, "little"))
        f.write((54).to_bytes(4, "little"))
        f.write((40).to_bytes(4, "little"))
        f.write(width.to_bytes(4, "little"))
        f.write(height.to_bytes(4, "little"))
        f.write((1).to_bytes(2, "little"))
        f.write((24).to_bytes(2, "little"))
        f.write((0).to_bytes(4, "little"))
        f.write(pixel_data_size.to_bytes(4, "little"))
        f.write((2835).to_bytes(4, "little"))
        f.write((2835).to_bytes(4, "little"))
        f.write((0).to_bytes(4, "little"))
        f.write((0).to_bytes(4, "little"))
        padding = b"\x00" * (row_stride - width * 3)
        for row in reversed(img):
            for r, g, b in row:
                f.write(bytes((b, g, r)))
            f.write(padding)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="objectB_text_to_3d_package/results/final_phone_mesh.ply",
    )
    parser.add_argument(
        "--preview",
        default="objectB_text_to_3d_package/results/final_phone_preview.svg",
    )
    parser.add_argument(
        "--preview-bmp",
        default="objectB_text_to_3d_package/results/final_phone_preview.bmp",
    )
    args = parser.parse_args()

    mesh = build_phone_mesh()
    write_ply(mesh, Path(args.output))
    write_preview_svg(Path(args.preview))
    write_preview_bmp(Path(args.preview_bmp))
    print(f"saved {args.output} vertices {len(mesh.vertices)} faces {len(mesh.faces)}")
    print(f"saved {args.preview}")
    print(f"saved {args.preview_bmp}")


if __name__ == "__main__":
    main()
