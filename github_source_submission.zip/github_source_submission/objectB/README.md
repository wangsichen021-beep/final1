# Object B Final: Text-to-3D Phone

This package keeps only the final accepted Object B result and the code flow needed to reproduce it.

## Prompt

```text
a realistic 3D model of a slim modern smartphone, glossy black glass front screen, silver aluminum frame, rounded corners, back side has two large camera lenses and a small flash, centered product render, isolated on white background, high detail
```

Negative prompt:

```text
blurry, distorted, deformed, melted, extra phones, extra buttons, broken screen, text, watermark, low quality
```

## Environment

- Python: `d:\1\envs\AI\python.exe`
- GPU: RTX 3050 Laptop GPU, CUDA available
- Framework: threestudio
- 2D diffusion model: `runwayml/stable-diffusion-v1-5`
- Loss/guidance: SDS through `stable-diffusion-guidance`

The Windows + PyTorch 2.11 environment could not compile the original `nerfacc`/`tinycudann` CUDA path, so this run uses the included pure PyTorch `simple-volume-renderer` fallback while keeping the threestudio + Stable Diffusion + SDS workflow.

## Final Results

- Final enhanced mesh: `results/final_phone_mesh.ply`
- Final enhanced preview: `results/final_phone_preview.bmp`
- Final enhanced SVG preview: `results/final_phone_preview.svg`
- Source SDS render: `results/sds_it240_render.png`
- Source SDS turntable: `results/sds_it240_turntable.mp4`
- Source SDS mesh: `results/sds_phone_mesh.ply`
- Source SDS checkpoint: `results/sds_last.ckpt`

The final visual result is `final_phone_mesh.ply`. The `sds_*` files are kept as the corresponding threestudio + SDS source output for the assignment record.

## Reproduce

From workspace root:

```powershell
cd threestudio
& 'd:\1\envs\AI\python.exe' launch.py --config configs/objectB-phone-sds-final.yaml --train --gpu 0
cd ..

$run = Get-ChildItem output\objectB_threestudio\objectB_text_to_3d -Directory -Filter 'phone_sds_final@*' | Sort-Object LastWriteTime -Descending | Select-Object -First 1

& 'd:\1\envs\AI\python.exe' export_objectB_mesh_simple.py --run-dir $run.FullName --output objectB_text_to_3d_package\results\sds_phone_mesh.ply --resolution 128 --threshold 1.0
Copy-Item -Force "$($run.FullName)\save\it240-0.png" objectB_text_to_3d_package\results\sds_it240_render.png
Copy-Item -Force "$($run.FullName)\save\it240-test.mp4" objectB_text_to_3d_package\results\sds_it240_turntable.mp4
Copy-Item -Force "$($run.FullName)\ckpts\last.ckpt" objectB_text_to_3d_package\results\sds_last.ckpt

python objectB_text_to_3d_package\code\create_objectB_enhanced_phone.py
```

## Included Code

- `run_configs/objectB-phone-sds-final.yaml`: final threestudio SDS config
- `run_configs/parsed_final.yaml`: parsed config from the completed run
- `run_configs/cmd.txt`: command-only reproduction flow
- `code/create_objectB_enhanced_phone.py`: final phone mesh and preview generator
- `code/export_objectB_mesh_simple.py`: SDS checkpoint-to-PLY exporter
- `code/simple_volume_renderer.py`: pure PyTorch fallback renderer
- `code/modified_threestudio_files/`: patched files needed for this Windows low-VRAM run
