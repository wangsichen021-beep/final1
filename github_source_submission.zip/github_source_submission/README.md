# 3D Reconstruction and Generation Project Source

本目录是 GitHub 源码提交版，只包含代码、运行配置和说明文档，不包含大体积结果文件。

## 目录

- `objectA/`：真实物体多视角重建，COLMAP + 2D Gaussian Splatting + mesh/可视化脚本。
- `objectB/`：文本到 3D 生成，threestudio + SDSLoss 手机生成脚本和配置。
- `objectC/`：单图到 3D 生成，Magic123 相关脚本和配置。
- `scene_fusion/`：背景场景、三物体融合、展示版多视角漫游渲染脚本。

## 未提交的大文件

以下文件不放入 GitHub 仓库，展示效果放在报告中：

- `.zip` 最终结果包
- `.mp4` 漫游/turntable 视频
- `.ply` 重建模型和 mesh
- `.ckpt/.pth/.pt` 训练权重
- `output/`、`results/`、原始数据集和中间缓存

## 复现说明

各子目录中保留了对应 README、代码和运行配置。完整复现需要本地准备：

- CUDA PyTorch 环境
- COLMAP
- 2D Gaussian Splatting 源码
- threestudio / Magic123 相关依赖

本机实验结果和展示视频已经在报告中展示；GitHub 仓库主要提交源码和流程说明。
