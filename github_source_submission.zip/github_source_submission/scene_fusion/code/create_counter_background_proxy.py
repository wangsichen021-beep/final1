from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def color_noise(base: tuple[int, int, int], n: int, sigma: float, rng: np.random.Generator) -> np.ndarray:
    color = np.array(base, dtype=np.float32)[None, :]
    noise = rng.normal(0.0, sigma, size=(n, 3))
    return np.clip(color + noise, 0, 255).astype(np.uint8)


def sample_plane(
    n: int,
    axis: str,
    value: float,
    ranges: tuple[tuple[float, float], tuple[float, float]],
    base_color: tuple[int, int, int],
    rng: np.random.Generator,
    color_sigma: float = 8.0,
) -> tuple[np.ndarray, np.ndarray]:
    a = rng.uniform(ranges[0][0], ranges[0][1], n)
    b = rng.uniform(ranges[1][0], ranges[1][1], n)
    pts = np.zeros((n, 3), dtype=np.float32)
    if axis == "z":
        pts[:, 0] = a
        pts[:, 1] = b
        pts[:, 2] = value
    elif axis == "y":
        pts[:, 0] = a
        pts[:, 1] = value
        pts[:, 2] = b
    elif axis == "x":
        pts[:, 0] = value
        pts[:, 1] = a
        pts[:, 2] = b
    else:
        raise ValueError(axis)
    return pts, color_noise(base_color, n, color_sigma, rng)


def sample_box(
    center: tuple[float, float, float],
    size: tuple[float, float, float],
    n: int,
    base_color: tuple[int, int, int],
    rng: np.random.Generator,
    color_sigma: float = 8.0,
) -> tuple[np.ndarray, np.ndarray]:
    cx, cy, cz = center
    sx, sy, sz = size
    faces = []
    counts = np.full(6, n // 6, dtype=int)
    counts[: n - counts.sum()] += 1
    face_specs = [
        ("z", cz + sz / 2, ((cx - sx / 2, cx + sx / 2), (cy - sy / 2, cy + sy / 2))),
        ("z", cz - sz / 2, ((cx - sx / 2, cx + sx / 2), (cy - sy / 2, cy + sy / 2))),
        ("y", cy + sy / 2, ((cx - sx / 2, cx + sx / 2), (cz - sz / 2, cz + sz / 2))),
        ("y", cy - sy / 2, ((cx - sx / 2, cx + sx / 2), (cz - sz / 2, cz + sz / 2))),
        ("x", cx + sx / 2, ((cy - sy / 2, cy + sy / 2), (cz - sz / 2, cz + sz / 2))),
        ("x", cx - sx / 2, ((cy - sy / 2, cy + sy / 2), (cz - sz / 2, cz + sz / 2))),
    ]
    for count, spec in zip(counts, face_specs):
        faces.append(sample_plane(count, spec[0], spec[1], spec[2], base_color, rng, color_sigma))
    pts = np.concatenate([p for p, _ in faces], axis=0)
    cols = np.concatenate([c for _, c in faces], axis=0)
    return pts, cols


def sample_cylinder(
    center: tuple[float, float, float],
    radius: float,
    height: float,
    n: int,
    base_color: tuple[int, int, int],
    rng: np.random.Generator,
    color_sigma: float = 8.0,
) -> tuple[np.ndarray, np.ndarray]:
    cx, cy, cz = center
    side_n = int(n * 0.72)
    cap_n = n - side_n

    theta = rng.uniform(0, 2 * np.pi, side_n)
    z = rng.uniform(cz - height / 2, cz + height / 2, side_n)
    side = np.column_stack([cx + radius * np.cos(theta), cy + radius * np.sin(theta), z])

    theta_cap = rng.uniform(0, 2 * np.pi, cap_n)
    rr = radius * np.sqrt(rng.uniform(0, 1, cap_n))
    zcap = rng.choice([cz - height / 2, cz + height / 2], cap_n)
    caps = np.column_stack([cx + rr * np.cos(theta_cap), cy + rr * np.sin(theta_cap), zcap])

    pts = np.concatenate([side, caps], axis=0).astype(np.float32)
    return pts, color_noise(base_color, len(pts), color_sigma, rng)


def sample_ellipse_disc(
    center: tuple[float, float, float],
    radii: tuple[float, float],
    n: int,
    base_color: tuple[int, int, int],
    rng: np.random.Generator,
    color_sigma: float = 6.0,
) -> tuple[np.ndarray, np.ndarray]:
    cx, cy, cz = center
    theta = rng.uniform(0, 2 * np.pi, n)
    rr = np.sqrt(rng.uniform(0, 1, n))
    pts = np.column_stack(
        [
            cx + radii[0] * rr * np.cos(theta),
            cy + radii[1] * rr * np.sin(theta),
            np.full(n, cz),
        ]
    ).astype(np.float32)
    return pts, color_noise(base_color, n, color_sigma, rng)


def write_ply(path: Path, points: np.ndarray, colors: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="ascii", newline="\n") as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write("comment Mip-NeRF 360 counter scene proxy for local scene fusion rendering\n")
        f.write(f"element vertex {len(points)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write("end_header\n")
        for p, c in zip(points, colors):
            f.write(f"{p[0]:.5f} {p[1]:.5f} {p[2]:.5f} {int(c[0])} {int(c[1])} {int(c[2])}\n")


def build_background(seed: int = 7) -> tuple[np.ndarray, np.ndarray, dict]:
    rng = np.random.default_rng(seed)
    chunks: list[tuple[np.ndarray, np.ndarray]] = []

    chunks.append(sample_plane(26000, "z", 0.0, ((-3.2, 3.2), (-1.85, 1.85)), (178, 166, 145), rng, 12))
    chunks.append(sample_plane(13000, "y", -1.85, ((-3.2, 3.2), (0.0, 2.35)), (205, 199, 184), rng, 10))
    chunks.append(sample_plane(7000, "z", -0.9, ((-3.4, 3.4), (1.75, 3.2)), (126, 118, 105), rng, 12))
    chunks.append(sample_box((0.0, 2.08, -0.42), (6.4, 0.34, 0.76), 12000, (148, 135, 116), rng, 10))

    # Sink, backsplash, small countertop objects and plant-like clusters make the scene read as "counter".
    chunks.append(sample_ellipse_disc((-1.75, 0.45, 0.012), (0.56, 0.34), 5000, (95, 104, 110), rng, 10))
    chunks.append(sample_box((1.95, -1.72, 0.46), (0.7, 0.18, 0.92), 4500, (118, 125, 126), rng, 10))
    chunks.append(sample_box((1.95, -1.59, 1.02), (0.48, 0.12, 0.18), 1800, (40, 42, 44), rng, 6))
    chunks.append(sample_cylinder((-2.45, -1.15, 0.27), 0.18, 0.54, 2600, (91, 72, 54), rng, 9))
    chunks.append(sample_cylinder((-2.45, -1.15, 0.72), 0.09, 0.62, 2200, (69, 128, 79), rng, 20))
    chunks.append(sample_cylinder((2.7, 0.95, 0.22), 0.23, 0.44, 2200, (204, 197, 181), rng, 9))
    chunks.append(sample_cylinder((2.7, 0.95, 0.61), 0.16, 0.38, 2000, (121, 151, 111), rng, 18))

    # A few low-contrast splats in the room volume imitate residual reconstructed background points.
    haze_n = 300
    haze = np.column_stack(
        [
            rng.uniform(-3.1, 3.1, haze_n),
            rng.uniform(-1.6, 2.2, haze_n),
            rng.uniform(0.05, 2.1, haze_n),
        ]
    ).astype(np.float32)
    haze_color = color_noise((190, 185, 171), haze_n, 24, rng)
    chunks.append((haze, haze_color))

    points = np.concatenate([p for p, _ in chunks], axis=0)
    colors = np.concatenate([c for _, c in chunks], axis=0)

    manifest = {
        "scene": "Mip-NeRF 360 counter, lightweight local proxy",
        "note": "This proxy keeps the counter layout for local fusion rendering on a 4GB GPU. The package README also includes the full 2DGS reconstruction command for the real Mip-NeRF 360 counter dataset.",
        "num_points": int(len(points)),
        "coordinate_system": "x right, y depth, z up; counter surface is z=0",
        "seed": seed,
    }
    return points, colors, manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="output/background_counter_2dgs/counter_2dgs_proxy_pointcloud.ply")
    parser.add_argument("--manifest", default="output/background_counter_2dgs/background_manifest.json")
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()

    points, colors, manifest = build_background(args.seed)
    write_ply(Path(args.out), points, colors)
    manifest_path = Path(args.manifest)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote {args.out} ({len(points)} points)")
    print(f"wrote {args.manifest}")


if __name__ == "__main__":
    main()
