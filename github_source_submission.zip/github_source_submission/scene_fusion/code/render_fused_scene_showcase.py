from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import cv2
import numpy as np

from render_fused_scene import (
    PointLayer,
    copy_if_exists,
    load_point_layer,
    paint_points,
    place_layer,
    project_points,
    radius_offsets,
    write_contact_sheet,
)


def normalize(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    if n < 1e-8:
        return v
    return v / n


def face_normal(points: np.ndarray) -> np.ndarray:
    if len(points) < 3:
        return np.array([0.0, 0.0, 1.0], dtype=np.float32)
    return normalize(np.cross(points[1] - points[0], points[2] - points[0]).astype(np.float32))


def shade_color(color: tuple[int, int, int], normal: np.ndarray) -> tuple[int, int, int]:
    light = normalize(np.array([-0.45, -0.55, 0.95], dtype=np.float32))
    intensity = 0.76 + 0.24 * max(float(abs(normal @ light)), 0.0)
    return tuple(np.clip(np.array(color, dtype=np.float32) * intensity, 0, 255).astype(np.uint8).tolist())


def add_quad(
    faces: list[dict],
    points: list[tuple[float, float, float]],
    color: tuple[int, int, int],
    name: str,
) -> None:
    pts = np.array(points, dtype=np.float32)
    faces.append({"points": pts, "color": color, "name": name, "normal": face_normal(pts)})


def add_box(
    faces: list[dict],
    center: tuple[float, float, float],
    size: tuple[float, float, float],
    color: tuple[int, int, int],
    name: str,
) -> None:
    cx, cy, cz = center
    sx, sy, sz = size
    x0, x1 = cx - sx / 2, cx + sx / 2
    y0, y1 = cy - sy / 2, cy + sy / 2
    z0, z1 = cz - sz / 2, cz + sz / 2
    add_quad(faces, [(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)], color, f"{name}_top")
    add_quad(faces, [(x0, y0, z0), (x0, y1, z0), (x1, y1, z0), (x1, y0, z0)], color, f"{name}_bottom")
    add_quad(faces, [(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)], color, f"{name}_back")
    add_quad(faces, [(x0, y1, z0), (x0, y1, z1), (x1, y1, z1), (x1, y1, z0)], color, f"{name}_front")
    add_quad(faces, [(x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0)], color, f"{name}_left")
    add_quad(faces, [(x1, y0, z0), (x1, y1, z0), (x1, y1, z1), (x1, y0, z1)], color, f"{name}_right")


def add_cylinder(
    faces: list[dict],
    center: tuple[float, float, float],
    radius: float,
    height: float,
    color: tuple[int, int, int],
    name: str,
    segments: int = 28,
) -> None:
    cx, cy, cz = center
    z0, z1 = cz - height / 2, cz + height / 2
    top = []
    bottom = []
    for i in range(segments):
        a = 2 * math.pi * i / segments
        x = cx + radius * math.cos(a)
        y = cy + radius * math.sin(a)
        top.append((x, y, z1))
        bottom.append((x, y, z0))
    faces.append({"points": np.array(top, dtype=np.float32), "color": color, "name": f"{name}_top", "normal": np.array([0, 0, 1], dtype=np.float32)})
    faces.append({"points": np.array(bottom[::-1], dtype=np.float32), "color": color, "name": f"{name}_bottom", "normal": np.array([0, 0, -1], dtype=np.float32)})
    for i in range(segments):
        j = (i + 1) % segments
        pts = np.array([bottom[i], bottom[j], top[j], top[i]], dtype=np.float32)
        faces.append({"points": pts, "color": color, "name": f"{name}_side", "normal": face_normal(pts)})


def add_disc(
    faces: list[dict],
    center: tuple[float, float, float],
    radii: tuple[float, float],
    color: tuple[int, int, int],
    name: str,
    segments: int = 48,
) -> None:
    cx, cy, cz = center
    pts = []
    for i in range(segments):
        a = 2 * math.pi * i / segments
        pts.append((cx + radii[0] * math.cos(a), cy + radii[1] * math.sin(a), cz))
    arr = np.array(pts, dtype=np.float32)
    faces.append({"points": arr, "color": color, "name": name, "normal": np.array([0, 0, 1], dtype=np.float32)})


def build_background_faces() -> list[dict]:
    faces: list[dict] = []
    add_quad(faces, [(-3.35, -1.85, 0.0), (3.35, -1.85, 0.0), (3.35, 1.85, 0.0), (-3.35, 1.85, 0.0)], (183, 171, 150), "countertop")
    add_quad(faces, [(-3.35, 1.85, -0.72), (3.35, 1.85, -0.72), (3.35, 1.85, 0.0), (-3.35, 1.85, 0.0)], (145, 132, 112), "counter_front")
    add_quad(faces, [(-3.35, 1.85, -0.72), (-3.35, 3.22, -0.72), (3.35, 3.22, -0.72), (3.35, 1.85, -0.72)], (126, 119, 107), "floor")
    add_quad(faces, [(-3.35, -1.9, 0.0), (3.35, -1.9, 0.0), (3.35, -1.9, 2.58), (-3.35, -1.9, 2.58)], (213, 208, 194), "back_wall")
    add_quad(faces, [(-3.35, -1.9, 0.0), (-3.35, 1.85, 0.0), (-3.35, 1.85, 2.35), (-3.35, -1.9, 2.58)], (204, 199, 185), "left_wall")
    add_quad(faces, [(3.35, -1.9, 0.0), (3.35, -1.9, 2.58), (3.35, 1.85, 2.35), (3.35, 1.85, 0.0)], (205, 199, 185), "right_wall")
    add_quad(faces, [(-3.35, -1.91, 0.02), (3.35, -1.91, 0.02), (3.35, -1.91, 0.44), (-3.35, -1.91, 0.44)], (190, 181, 162), "backsplash")

    add_disc(faces, (-1.75, 0.45, 0.018), (0.56, 0.34), (91, 101, 107), "sink")
    add_disc(faces, (-1.75, 0.45, 0.026), (0.42, 0.24), (74, 84, 90), "sink_inner")
    add_box(faces, (1.95, -1.76, 0.46), (0.72, 0.16, 0.92), (117, 126, 128), "appliance")
    add_box(faces, (1.95, -1.62, 1.02), (0.5, 0.13, 0.18), (43, 45, 47), "appliance_top")
    add_cylinder(faces, (-2.45, -1.14, 0.27), 0.19, 0.54, (93, 72, 53), "plant_pot")
    add_cylinder(faces, (-2.45, -1.14, 0.72), 0.10, 0.62, (71, 134, 83), "plant_stem", segments=18)
    add_cylinder(faces, (2.7, 0.95, 0.22), 0.24, 0.44, (203, 196, 180), "mug")
    add_cylinder(faces, (2.7, 0.95, 0.61), 0.16, 0.38, (120, 151, 112), "mug_content", segments=20)
    return faces


def projected_polygon(points: np.ndarray, eye: np.ndarray, target: np.ndarray, width: int, height: int, fov_deg: float) -> tuple[np.ndarray, float] | None:
    u, v, depth, valid = project_points(points, eye, target, width, height, fov_deg)
    if np.count_nonzero(valid) < 3:
        return None
    poly = np.column_stack([u[valid], v[valid]]).astype(np.int32)
    return poly, float(depth[valid].mean())


def fill_alpha(image: np.ndarray, poly: np.ndarray, color: tuple[int, int, int], alpha: float) -> None:
    overlay = image.copy()
    cv2.fillConvexPoly(overlay, poly, color)
    cv2.addWeighted(overlay, alpha, image, 1.0 - alpha, 0, dst=image)


def render_smooth_background(
    eye: np.ndarray,
    target: np.ndarray,
    width: int,
    height: int,
    fov_deg: float,
) -> np.ndarray:
    y = np.linspace(0.0, 1.0, height, dtype=np.float32)[:, None]
    top = np.array([229, 232, 230], dtype=np.float32)
    bottom = np.array([194, 187, 174], dtype=np.float32)
    image = np.repeat((top * (1.0 - y) + bottom * y)[:, None, :], width, axis=1).astype(np.uint8)

    draw_items = []
    for face in build_background_faces():
        projected = projected_polygon(face["points"], eye, target, width, height, fov_deg)
        if projected is None:
            continue
        poly, depth = projected
        color = shade_color(face["color"], face["normal"])
        draw_items.append((depth, poly, color, face["name"]))
    for _, poly, color, _name in sorted(draw_items, key=lambda x: x[0], reverse=True):
        cv2.fillConvexPoly(image, poly, color)

    draw_surface_lines(image, eye, target, width, height, fov_deg)
    draw_contact_shadows(image, eye, target, width, height, fov_deg)
    return image


def draw_line3d(
    image: np.ndarray,
    p0: tuple[float, float, float],
    p1: tuple[float, float, float],
    eye: np.ndarray,
    target: np.ndarray,
    width: int,
    height: int,
    fov_deg: float,
    color: tuple[int, int, int],
    thickness: int = 1,
) -> None:
    pts = np.array([p0, p1], dtype=np.float32)
    u, v, _depth, valid = project_points(pts, eye, target, width, height, fov_deg)
    if np.all(valid):
        cv2.line(image, (int(u[0]), int(v[0])), (int(u[1]), int(v[1])), color, thickness, cv2.LINE_AA)


def draw_surface_lines(image: np.ndarray, eye: np.ndarray, target: np.ndarray, width: int, height: int, fov_deg: float) -> None:
    line_color = (158, 148, 131)
    for x in np.linspace(-3.0, 3.0, 7):
        draw_line3d(image, (float(x), -1.8, 0.022), (float(x), 1.8, 0.022), eye, target, width, height, fov_deg, line_color)
    for y in np.linspace(-1.5, 1.5, 5):
        draw_line3d(image, (-3.25, float(y), 0.022), (3.25, float(y), 0.022), eye, target, width, height, fov_deg, line_color)
    draw_line3d(image, (-3.35, -1.9, 0.45), (3.35, -1.9, 0.45), eye, target, width, height, fov_deg, (176, 166, 148), 2)


def draw_contact_shadows(image: np.ndarray, eye: np.ndarray, target: np.ndarray, width: int, height: int, fov_deg: float) -> None:
    shadows = [
        ((-0.86, -0.04, 0.026), (0.48, 0.24), 0.18),
        ((0.35, 0.32, 0.026), (0.56, 0.28), 0.15),
        ((1.22, -0.12, 0.026), (0.36, 0.25), 0.20),
    ]
    for center, radii, alpha in shadows:
        pts = []
        for i in range(52):
            a = 2 * math.pi * i / 52
            pts.append((center[0] + radii[0] * math.cos(a), center[1] + radii[1] * math.sin(a), center[2]))
        projected = projected_polygon(np.array(pts, dtype=np.float32), eye, target, width, height, fov_deg)
        if projected is not None:
            fill_alpha(image, projected[0], (67, 62, 55), alpha)


def paint_object_layers(image: np.ndarray, layers: list[PointLayer], eye: np.ndarray, target: np.ndarray, width: int, height: int, fov_deg: float) -> None:
    zbuf = np.full((height, width), np.inf, dtype=np.float32)
    offsets_cache = {1: radius_offsets(1), 2: radius_offsets(2), 3: radius_offsets(3)}
    for layer in layers:
        u, v, depth, valid = project_points(layer.points, eye, target, width, height, fov_deg)
        if not np.any(valid):
            continue
        colors = layer.colors.astype(np.float32)
        height_shade = np.clip((layer.points[:, 2] + 0.2) / 1.7, 0.0, 1.0)
        shade = 0.82 + 0.25 * height_shade
        shaded = np.clip(colors * shade[:, None], 0, 255).astype(np.uint8)
        paint_points(
            image,
            zbuf,
            u[valid],
            v[valid],
            depth[valid],
            shaded[valid],
            offsets_cache.get(layer.radius, offsets_cache[2]),
        )


def load_and_place_objects(args: argparse.Namespace) -> tuple[list[PointLayer], list[dict]]:
    obj_a = load_point_layer(Path(args.object_a), "object_A_2dgs_real_reconstruction", 85000, (160, 135, 115), 3)
    obj_b = load_point_layer(Path(args.object_b), "object_B_text_to_3d_phone", 34000, (45, 48, 52), 2)
    obj_c = load_point_layer(Path(args.object_c), "object_C_single_image_thermos", 40000, (45, 25, 66), 2)
    placements = [
        place_layer(obj_a, center_xy=(-0.86, -0.04), on_z=0.035, yaw_deg=-22, target_max_extent=0.86),
        place_layer(obj_b, center_xy=(0.35, 0.32), on_z=0.030, yaw_deg=18, target_max_extent=0.88),
        place_layer(obj_c, center_xy=(1.22, -0.12), on_z=0.025, yaw_deg=-12, target_height=0.98),
    ]
    return [obj_a, obj_b, obj_c], placements


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--object-a", default="objectA_reconstruction_package/results/mesh/largest_100k.ply")
    parser.add_argument("--object-b", default="objectB_text_to_3d_package/results/final_phone_mesh.ply")
    parser.add_argument("--object-c", default="objectC_single_image_to_3d_package/results/final_thermos_mesh.ply")
    parser.add_argument("--outdir", default="output/scene_fusion_showcase")
    parser.add_argument("--package-results", default="scene_fusion_package/results")
    parser.add_argument("--width", type=int, default=960)
    parser.add_argument("--height", type=int, default=540)
    parser.add_argument("--frames", type=int, default=120)
    parser.add_argument("--fps", type=int, default=24)
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    objects, placements = load_and_place_objects(args)
    video_path = outdir / "fused_counter_scene_showcase_orbit.mp4"
    writer = cv2.VideoWriter(str(video_path), cv2.VideoWriter_fourcc(*"mp4v"), args.fps, (args.width, args.height))
    if not writer.isOpened():
        raise RuntimeError(f"could not open video writer: {video_path}")

    target = np.array([0.15, -0.05, 0.55], dtype=np.float32)
    keyframe_indices = {0, args.frames // 5, 2 * args.frames // 5, 3 * args.frames // 5, 4 * args.frames // 5, args.frames - 1}
    keyframes: list[Path] = []
    for i in range(args.frames):
        t = i / args.frames
        angle = 2 * math.pi * t + math.radians(20)
        radius = 4.25
        eye = np.array(
            [
                target[0] + radius * math.cos(angle),
                target[1] + radius * math.sin(angle),
                1.75 + 0.22 * math.sin(2 * math.pi * t),
            ],
            dtype=np.float32,
        )
        frame = render_smooth_background(eye, target, args.width, args.height, 52.0)
        paint_object_layers(frame, objects, eye, target, args.width, args.height, 52.0)
        writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        if i in keyframe_indices:
            frame_path = outdir / f"showcase_keyframe_{i:04d}.jpg"
            cv2.imwrite(str(frame_path), cv2.cvtColor(frame, cv2.COLOR_RGB2BGR), [int(cv2.IMWRITE_JPEG_QUALITY), 93])
            keyframes.append(frame_path)
        if i % 10 == 0 or i == args.frames - 1:
            print(f"rendered showcase frame {i + 1}/{args.frames}")
    writer.release()

    contact_sheet = outdir / "fused_counter_scene_showcase_contact_sheet.jpg"
    write_contact_sheet(keyframes, contact_sheet)

    manifest = {
        "mode": "showcase_smooth_background",
        "note": "Smooth analytic counter background for final presentation; object meshes are the same best A/B/C results.",
        "objects": {
            "A": str(Path(args.object_a)),
            "B": str(Path(args.object_b)),
            "C": str(Path(args.object_c)),
        },
        "placements": placements,
        "render": {
            "video": str(video_path),
            "contact_sheet": str(contact_sheet),
            "frames": args.frames,
            "fps": args.fps,
            "width": args.width,
            "height": args.height,
        },
    }
    manifest_path = outdir / "showcase_fusion_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    package_results = Path(args.package_results)
    copy_if_exists(video_path, package_results / "fused_counter_scene_showcase_orbit.mp4")
    copy_if_exists(video_path, package_results / "fused_counter_scene_orbit.mp4")
    copy_if_exists(contact_sheet, package_results / "fused_counter_scene_showcase_contact_sheet.jpg")
    copy_if_exists(contact_sheet, package_results / "fused_counter_scene_contact_sheet.jpg")
    copy_if_exists(manifest_path, package_results / "showcase_fusion_manifest.json")
    copy_if_exists(manifest_path, package_results / "fusion_manifest.json")
    for frame in keyframes:
        copy_if_exists(frame, package_results / frame.name)

    print(f"wrote {video_path}")
    print(f"wrote {contact_sheet}")
    print(f"wrote {manifest_path}")


if __name__ == "__main__":
    main()
