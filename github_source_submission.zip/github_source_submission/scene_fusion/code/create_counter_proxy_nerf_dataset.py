from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import cv2
import numpy as np

from create_counter_background_proxy import build_background
from render_fused_scene import PointLayer, look_at, render_frame


def write_points3d_ply(path: Path, points: np.ndarray, colors: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="ascii", newline="\n") as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write("comment initialization point cloud for 2DGS counter proxy background\n")
        f.write(f"element vertex {len(points)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property float nx\n")
        f.write("property float ny\n")
        f.write("property float nz\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write("end_header\n")
        for p, c in zip(points, colors):
            f.write(
                f"{p[0]:.5f} {p[1]:.5f} {p[2]:.5f} "
                f"0.00000 0.00000 0.00000 {int(c[0])} {int(c[1])} {int(c[2])}\n"
            )


def camera_to_world(eye: np.ndarray, target: np.ndarray) -> list[list[float]]:
    right, up, forward = look_at(eye, target)
    matrix = np.eye(4, dtype=np.float32)
    matrix[:3, 0] = right
    matrix[:3, 1] = up
    matrix[:3, 2] = -forward
    matrix[:3, 3] = eye
    return matrix.tolist()


def write_split(
    outdir: Path,
    split: str,
    layer: PointLayer,
    frame_count: int,
    angle_offset: float,
    width: int,
    height: int,
    fov_deg: float,
) -> dict:
    image_dir = outdir / split
    image_dir.mkdir(parents=True, exist_ok=True)
    target = np.array([0.10, -0.05, 0.52], dtype=np.float32)
    frames = []
    for i in range(frame_count):
        t = i / frame_count
        angle = 2 * math.pi * t + angle_offset
        radius = 4.15
        eye = np.array(
            [
                target[0] + radius * math.cos(angle),
                target[1] + radius * math.sin(angle),
                1.62 + 0.18 * math.sin(2 * math.pi * t + 0.5),
            ],
            dtype=np.float32,
        )
        frame = render_frame([layer], eye, target, width, height, fov_deg)
        stem = f"r_{i:03d}"
        img_path = image_dir / f"{stem}.png"
        cv2.imwrite(str(img_path), cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        frames.append(
            {
                "file_path": f"{split}/{stem}",
                "transform_matrix": camera_to_world(eye, target),
            }
        )
    return {"camera_angle_x": math.radians(fov_deg), "frames": frames}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", default="data/counter_proxy_nerf_synthetic")
    parser.add_argument("--width", type=int, default=360)
    parser.add_argument("--height", type=int, default=220)
    parser.add_argument("--train-frames", type=int, default=18)
    parser.add_argument("--test-frames", type=int, default=6)
    parser.add_argument("--fov", type=float, default=52.0)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    points, colors, manifest = build_background(args.seed)
    write_points3d_ply(outdir / "points3d.ply", points, colors)
    layer = PointLayer("counter_proxy_background", points.astype(np.float32), colors.astype(np.uint8), 2)
    train = write_split(outdir, "train", layer, args.train_frames, math.radians(12), args.width, args.height, args.fov)
    test = write_split(outdir, "test", layer, args.test_frames, math.radians(42), args.width, args.height, args.fov)
    (outdir / "transforms_train.json").write_text(json.dumps(train, indent=2), encoding="utf-8")
    (outdir / "transforms_test.json").write_text(json.dumps(test, indent=2), encoding="utf-8")
    manifest.update(
        {
            "dataset_format": "NeRF synthetic / Blender transforms",
            "train_frames": args.train_frames,
            "test_frames": args.test_frames,
            "image_width": args.width,
            "image_height": args.height,
            "camera_angle_x_degrees": args.fov,
        }
    )
    (outdir / "dataset_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote synthetic 2DGS dataset to {outdir}")


if __name__ == "__main__":
    main()
