from __future__ import annotations

import argparse
import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
import trimesh


@dataclass
class PointLayer:
    name: str
    points: np.ndarray
    colors: np.ndarray
    radius: int


def as_mesh(obj: object) -> trimesh.Trimesh | trimesh.points.PointCloud:
    if isinstance(obj, trimesh.Scene):
        meshes = [geom for geom in obj.geometry.values() if isinstance(geom, trimesh.Trimesh)]
        if meshes:
            return trimesh.util.concatenate(meshes)
        clouds = [geom for geom in obj.geometry.values() if isinstance(geom, trimesh.points.PointCloud)]
        if clouds:
            vertices = np.concatenate([np.asarray(c.vertices) for c in clouds], axis=0)
            colors = np.concatenate([np.asarray(c.colors[:, :3]) for c in clouds], axis=0)
            return trimesh.points.PointCloud(vertices, colors=colors)
        raise ValueError("Scene contains no mesh or point cloud geometry")
    if isinstance(obj, (trimesh.Trimesh, trimesh.points.PointCloud)):
        return obj
    raise TypeError(type(obj))


def load_point_layer(
    path: Path,
    name: str,
    target_points: int | None,
    default_color: tuple[int, int, int],
    radius: int,
) -> PointLayer:
    geom = as_mesh(trimesh.load(path, process=False))
    if isinstance(geom, trimesh.points.PointCloud):
        points = np.asarray(geom.vertices, dtype=np.float32)
        colors = np.asarray(geom.colors[:, :3], dtype=np.uint8) if geom.colors is not None else None
        if colors is None or len(colors) != len(points):
            colors = np.tile(np.array(default_color, dtype=np.uint8), (len(points), 1))
    else:
        mesh = geom
        vertices = np.asarray(mesh.vertices, dtype=np.float32)
        vertex_colors = None
        if hasattr(mesh.visual, "vertex_colors") and len(mesh.visual.vertex_colors) == len(vertices):
            vertex_colors = np.asarray(mesh.visual.vertex_colors[:, :3], dtype=np.uint8)

        if target_points and len(mesh.faces) > 0:
            points, face_index = trimesh.sample.sample_surface(mesh, target_points)
            points = points.astype(np.float32)
            if vertex_colors is not None:
                colors = vertex_colors[np.asarray(mesh.faces)[face_index]].mean(axis=1).astype(np.uint8)
            elif hasattr(mesh.visual, "face_colors") and len(mesh.visual.face_colors) == len(mesh.faces):
                colors = np.asarray(mesh.visual.face_colors[face_index, :3], dtype=np.uint8)
            else:
                colors = np.tile(np.array(default_color, dtype=np.uint8), (len(points), 1))
        else:
            points = vertices
            if vertex_colors is not None:
                colors = vertex_colors
            else:
                colors = np.tile(np.array(default_color, dtype=np.uint8), (len(points), 1))
    return PointLayer(name=name, points=points, colors=colors, radius=radius)


def rot_x(angle: float) -> np.ndarray:
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]], dtype=np.float32)


def rot_y(angle: float) -> np.ndarray:
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]], dtype=np.float32)


def rot_z(angle: float) -> np.ndarray:
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], dtype=np.float32)


def place_layer(
    layer: PointLayer,
    center_xy: tuple[float, float],
    on_z: float,
    yaw_deg: float = 0.0,
    pitch_deg: float = 0.0,
    roll_deg: float = 0.0,
    target_height: float | None = None,
    target_max_extent: float | None = None,
) -> dict:
    pts = layer.points.astype(np.float32).copy()
    lo = pts.min(axis=0)
    hi = pts.max(axis=0)
    center = (lo + hi) * 0.5
    pts -= center

    extents = hi - lo
    if target_height is not None:
        scale = target_height / max(float(extents[2]), 1e-6)
    elif target_max_extent is not None:
        scale = target_max_extent / max(float(extents.max()), 1e-6)
    else:
        scale = 1.0
    pts *= scale

    rot = rot_z(math.radians(yaw_deg)) @ rot_y(math.radians(pitch_deg)) @ rot_x(math.radians(roll_deg))
    pts = pts @ rot.T
    after_lo = pts.min(axis=0)
    after_hi = pts.max(axis=0)
    pts[:, 0] += center_xy[0] - (after_lo[0] + after_hi[0]) * 0.5
    pts[:, 1] += center_xy[1] - (after_lo[1] + after_hi[1]) * 0.5
    pts[:, 2] += on_z - after_lo[2]

    layer.points = pts
    final_lo = pts.min(axis=0)
    final_hi = pts.max(axis=0)
    return {
        "name": layer.name,
        "source_bbox_min": lo.round(5).tolist(),
        "source_bbox_max": hi.round(5).tolist(),
        "placed_bbox_min": final_lo.round(5).tolist(),
        "placed_bbox_max": final_hi.round(5).tolist(),
        "scale": float(scale),
        "points": int(len(pts)),
        "radius": layer.radius,
    }


def load_background(path: Path) -> PointLayer:
    return load_point_layer(path, "background_counter", None, (180, 170, 150), 2)


def look_at(eye: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    forward = target - eye
    forward = forward / np.linalg.norm(forward)
    world_up = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    right = np.cross(forward, world_up)
    right = right / np.linalg.norm(right)
    up = np.cross(right, forward)
    up = up / np.linalg.norm(up)
    return right, up, forward


def project_points(
    points: np.ndarray,
    eye: np.ndarray,
    target: np.ndarray,
    width: int,
    height: int,
    fov_deg: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    right, up, forward = look_at(eye, target)
    rel = points - eye[None, :]
    x = rel @ right
    y = rel @ up
    z = rel @ forward
    valid = z > 0.05
    focal = 0.5 * width / math.tan(math.radians(fov_deg) * 0.5)
    u = (width * 0.5 + focal * x / z).astype(np.int32)
    v = (height * 0.52 - focal * y / z).astype(np.int32)
    valid &= (u >= -3) & (u < width + 3) & (v >= -3) & (v < height + 3)
    return u, v, z.astype(np.float32), valid


def paint_points(
    image: np.ndarray,
    zbuf: np.ndarray,
    u: np.ndarray,
    v: np.ndarray,
    depth: np.ndarray,
    colors: np.ndarray,
    offsets: list[tuple[int, int]],
) -> None:
    height, width = image.shape[:2]
    flat_image = image.reshape(-1, 3)
    flat_z = zbuf.reshape(-1)
    for dx, dy in offsets:
        px = u + dx
        py = v + dy
        keep = (px >= 0) & (px < width) & (py >= 0) & (py < height)
        if not np.any(keep):
            continue
        flat = py[keep] * width + px[keep]
        d = depth[keep]
        c = colors[keep]
        order = np.lexsort((d, flat))
        flat_sorted = flat[order]
        first = np.empty(len(flat_sorted), dtype=bool)
        first[0] = True
        first[1:] = flat_sorted[1:] != flat_sorted[:-1]
        chosen_flat = flat_sorted[first]
        chosen_depth = d[order][first]
        update = chosen_depth < flat_z[chosen_flat]
        if np.any(update):
            dst = chosen_flat[update]
            flat_z[dst] = chosen_depth[update]
            flat_image[dst] = c[order][first][update]


def radius_offsets(radius: int) -> list[tuple[int, int]]:
    offsets = []
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            if dx * dx + dy * dy <= radius * radius:
                offsets.append((dx, dy))
    return offsets


def render_frame(
    layers: list[PointLayer],
    eye: np.ndarray,
    target: np.ndarray,
    width: int,
    height: int,
    fov_deg: float,
) -> np.ndarray:
    y = np.linspace(0.0, 1.0, height, dtype=np.float32)[:, None]
    top = np.array([222, 226, 225], dtype=np.float32)
    bottom = np.array([174, 166, 151], dtype=np.float32)
    image = np.repeat((top * (1.0 - y) + bottom * y)[:, None, :], width, axis=1).astype(np.uint8)
    zbuf = np.full((height, width), np.inf, dtype=np.float32)

    offsets_cache = {1: radius_offsets(1), 2: radius_offsets(2), 3: radius_offsets(3)}
    sky = np.array([218, 222, 222], dtype=np.float32)
    for layer in layers:
        u, v, depth, valid = project_points(layer.points, eye, target, width, height, fov_deg)
        if not np.any(valid):
            continue
        colors = layer.colors.astype(np.float32)
        height_shade = np.clip((layer.points[:, 2] + 0.6) / 2.6, 0.0, 1.0)
        shade = 0.70 + 0.30 * height_shade
        fog = np.clip((depth - 4.0) / 5.0, 0.0, 0.55)
        shaded = colors * shade[:, None]
        shaded = shaded * (1.0 - fog[:, None]) + sky[None, :] * fog[:, None]
        shaded = np.clip(shaded, 0, 255).astype(np.uint8)
        paint_points(
            image,
            zbuf,
            u[valid],
            v[valid],
            depth[valid],
            shaded[valid],
            offsets_cache.get(layer.radius, offsets_cache[2]),
        )

    return image


def write_contact_sheet(frames: list[Path], out_path: Path) -> None:
    imgs = [cv2.imread(str(p)) for p in frames]
    imgs = [img for img in imgs if img is not None]
    if not imgs:
        return
    h, w = imgs[0].shape[:2]
    cols = 3
    rows = math.ceil(len(imgs) / cols)
    sheet = np.full((rows * h, cols * w, 3), 236, dtype=np.uint8)
    for i, img in enumerate(imgs):
        r, c = divmod(i, cols)
        sheet[r * h : (r + 1) * h, c * w : (c + 1) * w] = img
    cv2.imwrite(str(out_path), sheet)


def copy_if_exists(src: Path, dst: Path) -> None:
    if src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--background", default="output/background_counter_2dgs/counter_2dgs_proxy_pointcloud.ply")
    parser.add_argument("--object-a", default="objectA_reconstruction_package/results/mesh/largest_100k.ply")
    parser.add_argument("--object-b", default="objectB_text_to_3d_package/results/final_phone_mesh.ply")
    parser.add_argument("--object-c", default="objectC_single_image_to_3d_package/results/final_thermos_mesh.ply")
    parser.add_argument("--outdir", default="output/scene_fusion")
    parser.add_argument("--package-results", default="scene_fusion_package/results")
    parser.add_argument("--width", type=int, default=960)
    parser.add_argument("--height", type=int, default=540)
    parser.add_argument("--frames", type=int, default=120)
    parser.add_argument("--fps", type=int, default=24)
    args = parser.parse_args()

    background_path = Path(args.background)
    if not background_path.exists():
        raise FileNotFoundError(f"missing background point cloud: {background_path}")

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    background = load_background(background_path)
    obj_a = load_point_layer(Path(args.object_a), "object_A_2dgs_real_reconstruction", 80000, (160, 135, 115), 3)
    obj_b = load_point_layer(Path(args.object_b), "object_B_text_to_3d_phone", 30000, (45, 48, 52), 2)
    obj_c = load_point_layer(Path(args.object_c), "object_C_single_image_thermos", 36000, (45, 25, 66), 2)

    placements = []
    placements.append(place_layer(obj_a, center_xy=(-0.86, -0.04), on_z=0.035, yaw_deg=-22, target_max_extent=0.82))
    placements.append(place_layer(obj_b, center_xy=(0.35, 0.32), on_z=0.030, yaw_deg=18, target_max_extent=0.88))
    placements.append(place_layer(obj_c, center_xy=(1.22, -0.12), on_z=0.025, yaw_deg=-12, target_height=0.98))

    layers = [background, obj_a, obj_b, obj_c]
    video_path = outdir / "fused_counter_scene_orbit.mp4"
    writer = cv2.VideoWriter(str(video_path), cv2.VideoWriter_fourcc(*"mp4v"), args.fps, (args.width, args.height))
    if not writer.isOpened():
        raise RuntimeError(f"could not open video writer: {video_path}")

    target = np.array([0.15, -0.05, 0.55], dtype=np.float32)
    keyframe_indices = {0, args.frames // 5, 2 * args.frames // 5, 3 * args.frames // 5, 4 * args.frames // 5, args.frames - 1}
    keyframes: list[Path] = []
    for i in range(args.frames):
        t = i / args.frames
        angle = 2 * math.pi * t + math.radians(20)
        radius = 4.25
        eye = np.array(
            [
                target[0] + radius * math.cos(angle),
                target[1] + radius * math.sin(angle),
                1.75 + 0.22 * math.sin(2 * math.pi * t),
            ],
            dtype=np.float32,
        )
        frame = render_frame(layers, eye, target, args.width, args.height, 52.0)
        writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        if i in keyframe_indices:
            frame_path = outdir / f"fused_keyframe_{i:04d}.jpg"
            cv2.imwrite(str(frame_path), cv2.cvtColor(frame, cv2.COLOR_RGB2BGR), [int(cv2.IMWRITE_JPEG_QUALITY), 92])
            keyframes.append(frame_path)
        if i % 10 == 0 or i == args.frames - 1:
            print(f"rendered frame {i + 1}/{args.frames}")
    writer.release()

    contact_sheet = outdir / "fused_counter_scene_contact_sheet.jpg"
    write_contact_sheet(keyframes, contact_sheet)

    manifest = {
        "background": str(background_path),
        "objects": {
            "A": str(Path(args.object_a)),
            "B": str(Path(args.object_b)),
            "C": str(Path(args.object_c)),
        },
        "placements": placements,
        "render": {
            "video": str(video_path),
            "contact_sheet": str(contact_sheet),
            "frames": args.frames,
            "fps": args.fps,
            "width": args.width,
            "height": args.height,
        },
    }
    manifest_path = outdir / "fusion_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    package_results = Path(args.package_results)
    copy_if_exists(video_path, package_results / video_path.name)
    copy_if_exists(contact_sheet, package_results / contact_sheet.name)
    copy_if_exists(manifest_path, package_results / manifest_path.name)
    for frame in keyframes:
        copy_if_exists(frame, package_results / frame.name)
    copy_if_exists(background_path, package_results / "background_counter_2dgs_proxy.ply")

    print(f"wrote {video_path}")
    print(f"wrote {contact_sheet}")
    print(f"wrote {manifest_path}")


if __name__ == "__main__":
    main()
