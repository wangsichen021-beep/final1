$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = "d:\1\envs\AI\python.exe"

& $Python (Join-Path $PackageRoot "code\render_fused_scene_showcase.py") `
  --object-a (Join-Path $PackageRoot "sources\objects\objectA_largest_100k_best.ply") `
  --object-b (Join-Path $PackageRoot "sources\objects\objectB_final_phone_best.ply") `
  --object-c (Join-Path $PackageRoot "sources\objects\objectC_final_thermos_best.ply") `
  --outdir (Join-Path $PackageRoot "results") `
  --package-results (Join-Path $PackageRoot "results")

Write-Host "Done. Video:" (Join-Path $PackageRoot "results\fused_counter_scene_orbit.mp4")
