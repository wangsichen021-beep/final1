$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $PackageRoot "..")
$Python2DGS = "d:\1\envs\deep_learining\python.exe"
$PythonRender = "d:\1\envs\AI\python.exe"
$TwoDGSRoot = Join-Path $ProjectRoot "2d-gaussian-splatting"
$Dataset = Join-Path $ProjectRoot "data\counter_proxy_nerf_synthetic"
$Model = Join-Path $ProjectRoot "output\background_counter_2dgs\counter_proxy_2dgs_model"

& $PythonRender (Join-Path $PackageRoot "code\create_counter_proxy_nerf_dataset.py") `
  --outdir $Dataset

Push-Location $TwoDGSRoot
try {
  & $Python2DGS "train.py" `
    -s $Dataset `
    -m $Model `
    --iterations 300 `
    --resolution 1 `
    --quiet `
    --test_iterations 300 `
    --save_iterations 300
}
finally {
  Pop-Location
}

New-Item -ItemType Directory -Force -Path (Join-Path $PackageRoot "results\background_2dgs_model") | Out-Null
Copy-Item -Recurse -Force (Join-Path $Model "*") (Join-Path $PackageRoot "results\background_2dgs_model")

Write-Host "Done. 2DGS model:" (Join-Path $PackageRoot "results\background_2dgs_model")
