# 场景融合与渲染结果包

本包汇总了背景场景重建、三个物体插入、以及多视角漫游渲染所需的代码和结果。

## 最终结果

- `results/fused_counter_scene_orbit.mp4`：最终展示版多视角漫游视频，使用平滑 counter 背景。
- `results/fused_counter_scene_showcase_orbit.mp4`：同一视频的展示版命名副本。
- `results/fused_counter_scene_contact_sheet.jpg`：6 个关键视角拼图，方便快速检查比例和遮挡。
- `results/fusion_manifest.json`：A/B/C 三个物体的源文件、缩放、位置、渲染参数。
- `results/background_2dgs_model/`：本机实跑的短迭代 2DGS 背景模型输出，包含 `cameras.json`、`input.ply`、`point_cloud/iteration_300/point_cloud.ply`。

## 使用的三个物体

- A：`sources/objects/objectA_largest_100k_best.ply`
- B：`sources/objects/objectB_final_phone_best.ply`
- C：`sources/objects/objectC_final_thermos_best.ply`

这三个文件分别来自前面三个任务的最佳结果。融合渲染脚本会将它们统一尺度后放置到 counter 台面场景中。

## 背景场景说明

选定的公开背景场景目标是 Mip-NeRF 360 的 `counter`。当前机器是 RTX 3050 Laptop 4GB 显存，完整 Mip-NeRF 360 `counter` 的 2DGS 训练不适合在本机直接跑满，所以这里采用两层交付：

1. `run_counter_proxy_2dgs.ps1`：本机可复现的小型 `counter` proxy 数据集 + 300 iter 2DGS 训练，已经实跑成功。
2. `run_configs/run_full_mipnerf360_counter_2dgs.ps1`：完整 Mip-NeRF 360 `counter` 数据集上的 2DGS 命令模板，适合在更大显存机器上跑完整版。

最终展示视频使用平滑的 counter 几何背景，以减少点云直显造成的散点噪声；同时保留了实跑 2DGS 背景模型作为重建证据。

## 复现命令

从项目根目录运行：

```powershell
.\scene_fusion_package\run_scene_fusion.ps1
```

该命令默认生成展示版平滑背景视频。原始点云/splat 背景渲染脚本仍保留在 `code/render_fused_scene.py` 中，用于展示 2DGS proxy 背景的离散点效果。

如需重新生成本机短迭代 2DGS 背景模型：

```powershell
.\scene_fusion_package\run_counter_proxy_2dgs.ps1
```

注意：本机 2DGS Blender 数据读取器已做一个兼容性修复：`2d-gaussian-splatting/scene/dataset_readers.py` 中将 `np.byte` 改为 `np.uint8`，否则新版 PIL 会报 signed int8 图像类型错误。

## 参考来源

- Mip-NeRF 360 项目与数据集：https://jonbarron.info/mipnerf360/
- 2D Gaussian Splatting 项目：https://surfsplatting.github.io/
- NerfBaselines 2DGS / Mip-NeRF 360 基准：https://nerfbaselines.github.io/m-2d-gaussian-splatting
