$ErrorActionPreference = "Stop"

param(
  [string]$Dataset = "data\mipnerf360\counter",
  [string]$Model = "output\background_counter_2dgs\mipnerf360_counter_2dgs_full",
  [int]$Iterations = 30000
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $ScriptDir "..\..")
$TwoDGSRoot = Join-Path $ProjectRoot "2d-gaussian-splatting"
$Python2DGS = "d:\1\envs\deep_learining\python.exe"
$DatasetAbs = Join-Path $ProjectRoot $Dataset
$ModelAbs = Join-Path $ProjectRoot $Model

Write-Host "Dataset:" $DatasetAbs
Write-Host "Model:" $ModelAbs
Write-Host "This full Mip-NeRF 360 run is intended for a larger GPU. The local RTX 3050 Laptop has 4GB VRAM."

Push-Location $TwoDGSRoot
try {
  & $Python2DGS "train.py" `
    -s $DatasetAbs `
    -m $ModelAbs `
    --iterations $Iterations `
    --resolution 1

  & $Python2DGS "render.py" `
    -s $DatasetAbs `
    -m $ModelAbs `
    --unbounded `
    --skip_train `
    --skip_test `
    --mesh_res 1024
}
finally {
  Pop-Location
}
