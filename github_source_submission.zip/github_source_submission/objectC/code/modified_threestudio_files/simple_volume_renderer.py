from dataclasses import dataclass

import torch
import torch.nn.functional as F

import threestudio
from threestudio.models.background.base import BaseBackground
from threestudio.models.geometry.base import BaseImplicitGeometry
from threestudio.models.materials.base import BaseMaterial
from threestudio.models.renderers.base import VolumeRenderer
from threestudio.utils.typing import *


@threestudio.register("simple-volume-renderer")
class SimpleVolumeRenderer(VolumeRenderer):
    @dataclass
    class Config(VolumeRenderer.Config):
        num_samples_per_ray: int = 64
        randomized: bool = True
        near_plane: float = 0.0
        eps: float = 1.0e-6

    cfg: Config

    def configure(
        self,
        geometry: BaseImplicitGeometry,
        material: BaseMaterial,
        background: BaseBackground,
    ) -> None:
        super().configure(geometry, material, background)

    def _ray_sphere_intersections(
        self, rays_o: Float[Tensor, "Nr 3"], rays_d: Float[Tensor, "Nr 3"]
    ) -> Tuple[Float[Tensor, "Nr"], Float[Tensor, "Nr"], Bool[Tensor, "Nr"]]:
        radius = self.cfg.radius
        b = (rays_o * rays_d).sum(dim=-1)
        c = (rays_o * rays_o).sum(dim=-1) - radius * radius
        disc = b * b - c
        hit = disc > 0
        sqrt_disc = torch.sqrt(torch.clamp(disc, min=0.0))
        near = torch.clamp(-b - sqrt_disc, min=self.cfg.near_plane)
        far = torch.clamp(-b + sqrt_disc, min=self.cfg.near_plane)
        hit = hit & (far > near)
        return near, far, hit

    def forward(
        self,
        rays_o: Float[Tensor, "B H W 3"],
        rays_d: Float[Tensor, "B H W 3"],
        light_positions: Float[Tensor, "B 3"],
        bg_color: Optional[Tensor] = None,
        **kwargs,
    ) -> Dict[str, Float[Tensor, "..."]]:
        batch_size, height, width = rays_o.shape[:3]
        rays_o_flat = rays_o.reshape(-1, 3)
        rays_d_flat = F.normalize(rays_d.reshape(-1, 3), dim=-1)
        n_rays = rays_o_flat.shape[0]

        near, far, hit = self._ray_sphere_intersections(rays_o_flat, rays_d_flat)
        bins = torch.linspace(
            0.0,
            1.0,
            self.cfg.num_samples_per_ray + 1,
            device=rays_o.device,
            dtype=rays_o.dtype,
        )
        t_starts = near[:, None] * (1.0 - bins[:-1]) + far[:, None] * bins[:-1]
        t_ends = near[:, None] * (1.0 - bins[1:]) + far[:, None] * bins[1:]
        if self.training and self.cfg.randomized:
            t_mid = t_starts + torch.rand_like(t_starts) * (t_ends - t_starts)
        else:
            t_mid = 0.5 * (t_starts + t_ends)
        t_intervals = (t_ends - t_starts) * hit[:, None]

        positions = rays_o_flat[:, None, :] + rays_d_flat[:, None, :] * t_mid[..., None]
        positions_flat = positions.reshape(-1, 3)

        geo_out = self.geometry(
            positions_flat,
            output_normal=self.material.requires_normal,
        )
        density = geo_out["density"].reshape(n_rays, self.cfg.num_samples_per_ray, 1)
        alpha = 1.0 - torch.exp(-density * t_intervals[..., None])
        trans = torch.cumprod(
            torch.cat(
                [torch.ones_like(alpha[:, :1]), 1.0 - alpha + self.cfg.eps],
                dim=1,
            ),
            dim=1,
        )[:, :-1]
        weights = alpha * trans
        opacity = weights.sum(dim=1)

        material_inputs = {
            key: value.reshape(n_rays, self.cfg.num_samples_per_ray, -1)
            for key, value in geo_out.items()
            if key != "density"
        }
        light_flat = (
            light_positions[:, None, None, :]
            .expand(-1, height, width, -1)
            .reshape(n_rays, 3)
        )
        rgb_samples = self.material(
            viewdirs=rays_d_flat[:, None, :].expand_as(positions),
            positions=positions,
            light_positions=light_flat[:, None, :].expand_as(positions),
            **material_inputs,
            **kwargs,
        )
        comp_rgb_fg = (weights * rgb_samples).sum(dim=1)

        comp_rgb_bg = self.background(dirs=rays_d)
        bg_flat = comp_rgb_bg.reshape(n_rays, -1)
        if bg_color is not None:
            if bg_color.shape[:-1] == (batch_size,):
                bg_flat = (
                    bg_color[:, None, None, :]
                    .expand(-1, height, width, -1)
                    .reshape(n_rays, -1)
                )
            elif bg_color.shape[:-1] == (batch_size, height, width):
                bg_flat = bg_color.reshape(n_rays, -1)
            else:
                bg_flat = bg_color.reshape(n_rays, -1)

        comp_rgb = comp_rgb_fg + bg_flat * (1.0 - opacity)
        depth = (weights[..., 0] * t_mid).sum(dim=1, keepdim=True)

        out = {
            "comp_rgb": comp_rgb.view(batch_size, height, width, -1),
            "comp_rgb_fg": comp_rgb_fg.view(batch_size, height, width, -1),
            "comp_rgb_bg": comp_rgb_bg.view(batch_size, height, width, -1),
            "opacity": opacity.view(batch_size, height, width, 1),
            "depth": depth.view(batch_size, height, width, 1),
        }

        if "normal" in material_inputs:
            comp_normal = (weights * material_inputs["normal"]).sum(dim=1)
            comp_normal = F.normalize(comp_normal, dim=-1)
            comp_normal = (comp_normal + 1.0) * 0.5 * opacity
            out["comp_normal"] = comp_normal.view(batch_size, height, width, 3)

        if self.training:
            ray_indices = (
                torch.arange(n_rays, device=rays_o.device)
                .unsqueeze(1)
                .expand(-1, self.cfg.num_samples_per_ray)
                .reshape(-1)
            )
            out.update(
                {
                    "weights": weights.reshape(-1, 1),
                    "t_points": t_mid.reshape(-1, 1),
                    "t_intervals": t_intervals.reshape(-1, 1),
                    "t_dirs": rays_d_flat[:, None, :]
                    .expand_as(positions)
                    .reshape(-1, 3),
                    "ray_indices": ray_indices,
                    "points": positions_flat,
                    **geo_out,
                }
            )

        return out
