import argparse
from pathlib import Path

import cv2
import numpy as np


def parse_rect(value, width, height):
    if value is None:
        return (
            int(width * 0.24),
            int(height * 0.055),
            int(width * 0.52),
            int(height * 0.88),
        )
    parts = [float(item) for item in value.split(",")]
    if len(parts) != 4:
        raise ValueError("--rect must be x,y,w,h")
    if all(0.0 <= item <= 1.0 for item in parts):
        x, y, w, h = parts
        return int(x * width), int(y * height), int(w * width), int(h * height)
    return tuple(int(item) for item in parts)


def make_grabcut_mask(bgr, rect, iterations):
    mask = np.zeros(bgr.shape[:2], np.uint8)
    bgd_model = np.zeros((1, 65), np.float64)
    fgd_model = np.zeros((1, 65), np.float64)
    cv2.grabCut(bgr, mask, rect, bgd_model, fgd_model, iterations, cv2.GC_INIT_WITH_RECT)
    mask = np.where(
        (mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD),
        255,
        0,
    ).astype(np.uint8)
    kernel = np.ones((7, 7), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    mask = cv2.GaussianBlur(mask, (0, 0), 1.5)
    return mask


def bbox_from_alpha(alpha):
    ys, xs = np.where(alpha > 8)
    if len(xs) == 0 or len(ys) == 0:
        return None
    return xs.min(), ys.min(), xs.max() + 1, ys.max() + 1


def crop_to_square(rgba, alpha, output_size, padding):
    bbox = bbox_from_alpha(alpha)
    if bbox is None:
        raise RuntimeError("Could not find foreground mask")
    x0, y0, x1, y1 = bbox
    w = x1 - x0
    h = y1 - y0
    pad = int(max(w, h) * padding)
    x0 = max(x0 - pad, 0)
    y0 = max(y0 - pad, 0)
    x1 = min(x1 + pad, rgba.shape[1])
    y1 = min(y1 + pad, rgba.shape[0])

    crop = rgba[y0:y1, x0:x1]
    side = max(crop.shape[0], crop.shape[1])
    canvas = np.zeros((side, side, 4), dtype=np.uint8)
    oy = (side - crop.shape[0]) // 2
    ox = (side - crop.shape[1]) // 2
    canvas[oy : oy + crop.shape[0], ox : ox + crop.shape[1]] = crop
    return cv2.resize(canvas, (output_size, output_size), interpolation=cv2.INTER_AREA)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="纯净图片.png")
    parser.add_argument("--output", default="data/objectC/thermos_rgba.png")
    parser.add_argument("--preview", default="data/objectC/thermos_rgba_preview.png")
    parser.add_argument("--mask", default="data/objectC/thermos_mask.png")
    parser.add_argument("--rect", default=None)
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--output-size", type=int, default=768)
    parser.add_argument("--padding", type=float, default=0.08)
    args = parser.parse_args()

    src = Path(args.input)
    bgr = cv2.imread(str(src), cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(src)

    height, width = bgr.shape[:2]
    rect = parse_rect(args.rect, width, height)
    alpha = make_grabcut_mask(bgr, rect, args.iterations)

    if bbox_from_alpha(alpha) is None:
        x, y, w, h = rect
        alpha = np.zeros((height, width), dtype=np.uint8)
        alpha[y : y + h, x : x + w] = 255

    rgba = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGBA)
    rgba[..., 3] = alpha
    rgba_square = crop_to_square(rgba, alpha, args.output_size, args.padding)

    output = Path(args.output)
    preview = Path(args.preview)
    mask_path = Path(args.mask)
    output.parent.mkdir(parents=True, exist_ok=True)
    preview.parent.mkdir(parents=True, exist_ok=True)
    mask_path.parent.mkdir(parents=True, exist_ok=True)

    cv2.imwrite(str(output), cv2.cvtColor(rgba_square, cv2.COLOR_RGBA2BGRA))

    rgb = rgba_square[..., :3].astype(np.float32)
    a = rgba_square[..., 3:4].astype(np.float32) / 255.0
    checker = np.full_like(rgb, 240.0)
    composite = rgb * a + checker * (1.0 - a)
    cv2.imwrite(str(preview), cv2.cvtColor(composite.astype(np.uint8), cv2.COLOR_RGB2BGR))
    cv2.imwrite(str(mask_path), rgba_square[..., 3])

    print("saved", output)
    print("saved", preview)
    print("saved", mask_path)


if __name__ == "__main__":
    main()
