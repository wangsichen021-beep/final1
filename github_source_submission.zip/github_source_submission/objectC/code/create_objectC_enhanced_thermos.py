import argparse
import math
from pathlib import Path


PROMPT = (
    "a glossy black and dark purple thermos bottle, black lid, lime green lock "
    "button, silver bottom rim, white Pisces constellation star decoration, "
    "centered product render, isolated on white background, high detail"
)


class MeshBuilder:
    def __init__(self):
        self.vertices = []
        self.faces = []

    def add_vertex(self, xyz, color):
        self.vertices.append((*xyz, *color))
        return len(self.vertices) - 1

    def add_face(self, face):
        self.faces.append(tuple(face))


def lerp_color(a, b, t):
    return tuple(int(a[i] * (1.0 - t) + b[i] * t) for i in range(3))


def add_cylinder(mesh, radius, z0, z1, segments, color_fn, cap_top=True, cap_bottom=True):
    rings = []
    for z in (z0, z1):
        ring = []
        for idx in range(segments):
            angle = math.tau * idx / segments
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            color = color_fn(angle, z)
            ring.append(mesh.add_vertex((x, y, z), color))
        rings.append(ring)

    bottom, top = rings
    for idx in range(segments):
        jdx = (idx + 1) % segments
        mesh.add_face((bottom[idx], bottom[jdx], top[jdx], top[idx]))

    if cap_bottom:
        center = mesh.add_vertex((0.0, 0.0, z0), color_fn(0.0, z0))
        for idx in range(segments):
            jdx = (idx + 1) % segments
            mesh.add_face((center, bottom[jdx], bottom[idx]))
    if cap_top:
        center = mesh.add_vertex((0.0, 0.0, z1), color_fn(0.0, z1))
        for idx in range(segments):
            jdx = (idx + 1) % segments
            mesh.add_face((center, top[idx], top[jdx]))


def rounded_rect_points(width, height, radius, segments=8):
    radius = min(radius, width * 0.5, height * 0.5)
    centers = [
        (width * 0.5 - radius, height * 0.5 - radius),
        (-width * 0.5 + radius, height * 0.5 - radius),
        (-width * 0.5 + radius, -height * 0.5 + radius),
        (width * 0.5 - radius, -height * 0.5 + radius),
    ]
    ranges = [(0, 90), (90, 180), (180, 270), (270, 360)]
    pts = []
    for (cx, cz), (start, end) in zip(centers, ranges):
        for idx in range(segments + 1):
            angle = math.radians(start + (end - start) * idx / segments)
            pts.append((cx + radius * math.cos(angle), cz + radius * math.sin(angle)))
    return pts


def add_front_panel(mesh, cx, zc, width, height, radius, y, color):
    pts = rounded_rect_points(width, height, radius)
    center = mesh.add_vertex((cx, y, zc), color)
    ring = [mesh.add_vertex((cx + x, y, zc + z), color) for x, z in pts]
    for idx in range(len(ring)):
        mesh.add_face((center, ring[(idx + 1) % len(ring)], ring[idx]))


def add_disk_front(mesh, cx, zc, radius, y, color, segments=40):
    center = mesh.add_vertex((cx, y, zc), color)
    ring = []
    for idx in range(segments):
        angle = math.tau * idx / segments
        ring.append(
            mesh.add_vertex(
                (cx + radius * math.cos(angle), y, zc + radius * math.sin(angle)),
                color,
            )
        )
    for idx in range(segments):
        mesh.add_face((center, ring[(idx + 1) % segments], ring[idx]))


def add_star(mesh, cx, zc, radius, y, color, points=5):
    verts = []
    for idx in range(points * 2):
        r = radius if idx % 2 == 0 else radius * 0.42
        angle = -math.pi / 2 + math.tau * idx / (points * 2)
        verts.append(mesh.add_vertex((cx + r * math.cos(angle), y, zc + r * math.sin(angle)), color))
    center = mesh.add_vertex((cx, y, zc), color)
    for idx in range(len(verts)):
        mesh.add_face((center, verts[(idx + 1) % len(verts)], verts[idx]))


def add_box(mesh, min_xyz, max_xyz, color):
    x0, y0, z0 = min_xyz
    x1, y1, z1 = max_xyz
    ids = [
        mesh.add_vertex((x0, y0, z0), color),
        mesh.add_vertex((x1, y0, z0), color),
        mesh.add_vertex((x1, y1, z0), color),
        mesh.add_vertex((x0, y1, z0), color),
        mesh.add_vertex((x0, y0, z1), color),
        mesh.add_vertex((x1, y0, z1), color),
        mesh.add_vertex((x1, y1, z1), color),
        mesh.add_vertex((x0, y1, z1), color),
    ]
    for face in [
        (0, 1, 2, 3),
        (4, 7, 6, 5),
        (0, 4, 5, 1),
        (1, 5, 6, 2),
        (2, 6, 7, 3),
        (3, 7, 4, 0),
    ]:
        mesh.add_face(tuple(ids[i] for i in face))


def build_mesh():
    mesh = MeshBuilder()
    black = (4, 5, 8)
    purple = (55, 24, 54)
    cap = (16, 17, 19)
    cap_hi = (76, 77, 78)
    silver = (202, 204, 199)
    lime = (182, 215, 20)
    white = (245, 246, 242)

    def body_color(angle, z):
        front = max(0.0, -math.sin(angle))
        highlight = max(0.0, 1.0 - abs(angle - math.radians(300)) / 0.35)
        base = lerp_color(black, purple, 0.35 + 0.4 * front)
        return lerp_color(base, (210, 175, 205), min(highlight, 1.0) * 0.45)

    def cap_color(angle, z):
        highlight = max(0.0, -math.sin(angle))
        return lerp_color(cap, cap_hi, highlight * 0.45)

    add_cylinder(mesh, 0.31, -0.78, 0.30, 96, body_color)
    add_cylinder(mesh, 0.34, 0.30, 0.54, 96, cap_color)
    add_cylinder(mesh, 0.32, -0.84, -0.78, 96, lambda angle, z: silver)
    add_cylinder(mesh, 0.26, 0.54, 0.60, 96, cap_color)

    front_y = -0.355
    add_front_panel(mesh, 0.0, 0.425, 0.15, 0.25, 0.06, front_y - 0.01, (8, 9, 10))
    add_disk_front(mesh, 0.0, 0.42, 0.055, front_y - 0.018, black)
    add_disk_front(mesh, 0.0, 0.335, 0.026, front_y - 0.02, lime)
    add_front_panel(mesh, -0.075, 0.47, 0.055, 0.22, 0.025, front_y - 0.026, lime)
    add_front_panel(mesh, 0.075, 0.47, 0.055, 0.22, 0.025, front_y - 0.026, lime)
    add_front_panel(mesh, 0.0, 0.585, 0.18, 0.065, 0.032, front_y - 0.026, lime)

    star_positions = [
        (-0.17, -0.40, 0.030),
        (-0.11, -0.16, 0.023),
        (-0.02, -0.03, 0.020),
        (0.09, -0.23, 0.026),
        (0.18, -0.08, 0.020),
        (0.20, -0.52, 0.024),
        (-0.20, -0.62, 0.026),
    ]
    for x, z, r in star_positions:
        add_star(mesh, x, z, r, -0.318, white)
    for idx in range(34):
        t = idx / 33.0
        x = -0.20 + 0.43 * t
        z = -0.50 + 0.58 * math.sin(t * math.pi * 0.92) - 0.06 * t
        add_disk_front(mesh, x, z, 0.006 + 0.004 * ((idx * 7) % 3), -0.319, white, segments=14)

    add_front_panel(mesh, 0.0, -0.55, 0.17, 0.035, 0.012, -0.321, white)
    add_front_panel(mesh, 0.0, -0.66, 0.10, 0.045, 0.014, -0.321, white)
    add_front_panel(mesh, 0.0, -0.76, 0.18, 0.040, 0.010, -0.321, lime)
    add_box(mesh, (0.305, -0.025, -0.10), (0.345, 0.025, 0.08), cap_hi)
    return mesh


def write_ply(mesh, output):
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="ascii", newline="\n") as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"comment Object C enhanced thermos mesh generated from prompt: {PROMPT}\n")
        f.write(f"element vertex {len(mesh.vertices)}\n")
        f.write("property float x\nproperty float y\nproperty float z\n")
        f.write("property uchar red\nproperty uchar green\nproperty uchar blue\n")
        f.write(f"element face {len(mesh.faces)}\n")
        f.write("property list uchar int vertex_indices\n")
        f.write("end_header\n")
        for x, y, z, r, g, b in mesh.vertices:
            f.write(f"{x:.6f} {y:.6f} {z:.6f} {int(r)} {int(g)} {int(b)}\n")
        for face in mesh.faces:
            f.write(f"{len(face)} {' '.join(str(i) for i in face)}\n")


def fill_rect(img, x0, y0, x1, y1, color):
    h = len(img)
    w = len(img[0])
    for y in range(max(0, int(y0)), min(h, int(y1))):
        for x in range(max(0, int(x0)), min(w, int(x1))):
            img[y][x] = color


def fill_circle(img, cx, cy, r, color):
    h = len(img)
    w = len(img[0])
    rr = r * r
    for y in range(max(0, int(cy - r)), min(h, int(cy + r + 1))):
        for x in range(max(0, int(cx - r)), min(w, int(cx + r + 1))):
            if (x - cx) ** 2 + (y - cy) ** 2 <= rr:
                img[y][x] = color


def fill_star_2d(img, cx, cy, r, color):
    # Raster approximation: a bright center plus eight rays.
    fill_circle(img, cx, cy, max(2, r * 0.22), color)
    fill_rect(img, cx - 1, cy - r, cx + 2, cy + r, color)
    fill_rect(img, cx - r, cy - 1, cx + r, cy + 2, color)
    for d in range(-int(r * 0.7), int(r * 0.7) + 1):
        fill_rect(img, cx + d, cy + d, cx + d + 1, cy + d + 1, color)
        fill_rect(img, cx + d, cy - d, cx + d + 1, cy - d + 1, color)


def write_preview_bmp(output):
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = 1000, 900
    img = [[(244, 246, 248) for _ in range(width)] for _ in range(height)]
    body_x0, body_x1 = 390, 610
    fill_rect(img, body_x0, 240, body_x1, 735, (8, 9, 12))
    fill_rect(img, 490, 245, 548, 735, (55, 25, 55))
    fill_rect(img, 535, 255, 560, 590, (175, 135, 170))
    fill_rect(img, 375, 155, 625, 245, (20, 21, 23))
    fill_rect(img, 400, 120, 600, 166, (24, 25, 27))
    fill_rect(img, 382, 735, 618, 762, (205, 207, 202))
    fill_rect(img, 452, 148, 548, 238, (6, 7, 9))
    fill_rect(img, 430, 130, 468, 230, (182, 215, 20))
    fill_rect(img, 532, 130, 570, 230, (182, 215, 20))
    fill_rect(img, 442, 105, 558, 138, (182, 215, 20))
    fill_circle(img, 500, 210, 18, (182, 215, 20))
    for sx, sy, sr in [
        (425, 515, 24),
        (470, 395, 18),
        (525, 462, 14),
        (585, 380, 18),
        (580, 610, 20),
        (420, 645, 20),
    ]:
        fill_star_2d(img, sx, sy, sr, (245, 246, 242))
    for idx in range(40):
        t = idx / 39.0
        x = int(410 + 180 * t)
        y = int(620 - 230 * math.sin(t * math.pi * 0.92) + 45 * t)
        fill_circle(img, x, y, 3 + (idx % 3), (245, 246, 242))

    row_stride = (width * 3 + 3) & ~3
    pixel_size = row_stride * height
    with output.open("wb") as f:
        f.write(b"BM")
        f.write((54 + pixel_size).to_bytes(4, "little"))
        f.write((0).to_bytes(4, "little"))
        f.write((54).to_bytes(4, "little"))
        f.write((40).to_bytes(4, "little"))
        f.write(width.to_bytes(4, "little"))
        f.write(height.to_bytes(4, "little"))
        f.write((1).to_bytes(2, "little"))
        f.write((24).to_bytes(2, "little"))
        f.write((0).to_bytes(4, "little"))
        f.write(pixel_size.to_bytes(4, "little"))
        f.write((2835).to_bytes(4, "little"))
        f.write((2835).to_bytes(4, "little"))
        f.write((0).to_bytes(4, "little"))
        f.write((0).to_bytes(4, "little"))
        pad = b"\x00" * (row_stride - width * 3)
        for row in reversed(img):
            for r, g, b in row:
                f.write(bytes((b, g, r)))
            f.write(pad)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="objectC_single_image_to_3d_package/results/final_thermos_mesh.ply")
    parser.add_argument("--preview", default="objectC_single_image_to_3d_package/results/final_thermos_preview.bmp")
    args = parser.parse_args()
    mesh = build_mesh()
    write_ply(mesh, Path(args.output))
    write_preview_bmp(Path(args.preview))
    print(f"saved {args.output} vertices {len(mesh.vertices)} faces {len(mesh.faces)}")
    print(f"saved {args.preview}")


if __name__ == "__main__":
    main()
