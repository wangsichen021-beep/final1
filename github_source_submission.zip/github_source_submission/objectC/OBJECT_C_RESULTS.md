# Object C Final Results

Task C is completed with a Magic123 single-image-to-3D run and a final enhanced display mesh.

- Package: `objectC_single_image_to_3d_package/`
- Source image: `objectC_single_image_to_3d_package/data/source_thermos.png`
- RGBA foreground: `objectC_single_image_to_3d_package/data/thermos_rgba.png`
- Final display mesh: `objectC_single_image_to_3d_package/results/final_thermos_mesh.ply`
- Final display preview: `objectC_single_image_to_3d_package/results/final_thermos_preview.bmp`
- Raw Magic123 render: `objectC_single_image_to_3d_package/results/magic123_it60_render.png`
- Raw Magic123 turntable: `objectC_single_image_to_3d_package/results/magic123_it60_turntable.mp4`
- Raw Magic123 mesh: `objectC_single_image_to_3d_package/results/magic123_mesh.ply`
- Raw Magic123 checkpoint: `objectC_single_image_to_3d_package/results/magic123_last.ckpt`
- Reproduction commands: `objectC_single_image_to_3d_package/run_configs/cmd.txt`

The direct Magic123 output preserves the bottle/cap silhouette but is low-detail because it was run for 60 steps on a 4GB RTX 3050 with a pure PyTorch fallback renderer. The final presentation object is `final_thermos_mesh.ply`; the `magic123_*` files preserve the required Magic123 source result.
