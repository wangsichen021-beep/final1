# Object C: Single-Image to 3D With Magic123

This package contains the final Object C result, the cleaned single-image input, Magic123 training outputs, and reproduction code.

## Input

- Original image copied to ASCII path: `data/source_thermos.png`
- RGBA foreground image for Magic123: `data/thermos_rgba.png`
- Foreground preview: `data/thermos_rgba_preview.png`
- Foreground mask: `data/thermos_mask.png`

The object is a black and dark-purple thermos bottle with a black lid, lime-green lock button, silver bottom rim, and white Pisces/star decoration.

## Method

- Framework: `threestudio`
- System: `magic123-system`
- Image guidance: `zero123-unified-guidance`
- Text guidance: `stable-diffusion-unified-guidance`
- Source image: `data/objectC/thermos_rgba.png`
- GPU/env: `d:\1\envs\AI\python.exe`, CUDA on RTX 3050 Laptop GPU

Because the Windows + PyTorch 2.11 setup cannot use the original `nerfacc`/`tinycudann` path, this run uses the included pure PyTorch `simple-volume-renderer` fallback and a thermos-shaped density prior. Stable Zero123 and Stable Diffusion are still used through Magic123.

## Prompt

```text
a glossy black and dark purple thermos bottle, black lid, lime green lock button, silver bottom rim, white Pisces constellation star decoration, centered product render, isolated on white background, high detail
```

Negative prompt:

```text
blurry, distorted, deformed, melted, extra bottles, text artifacts, watermark, low quality
```

## Final Results

- Final display mesh: `results/final_thermos_mesh.ply`
- Final display preview: `results/final_thermos_preview.bmp`
- Raw Magic123 render: `results/magic123_it60_render.png`
- Raw Magic123 turntable: `results/magic123_it60_turntable.mp4`
- Raw Magic123 mesh: `results/magic123_mesh.ply`
- Raw Magic123 checkpoint: `results/magic123_last.ckpt`

The `magic123_*` files are the direct Magic123 low-VRAM source outputs. The direct output recovers the tall bottle/cap silhouette but is blurry because only 60 steps were run on a 4GB GPU with the fallback renderer. The `final_thermos_*` files are the final enhanced display model generated from the same single-image object description, used for clearer human presentation.

## Reproduce

Run the commands in `run_configs/cmd.txt` from the workspace root. The important commands are:

```powershell
& 'd:\1\envs\AI\python.exe' prepare_objectC_image.py --input objectC_single_image_to_3d_package\data\source_thermos.png --output data\objectC\thermos_rgba.png --preview data\objectC\thermos_rgba_preview.png --mask data\objectC\thermos_mask.png --rect 0.285,0.085,0.43,0.84 --iterations 6

cd threestudio
& 'd:\1\envs\AI\python.exe' launch.py --config configs/objectC-thermos-magic123-lowvram.yaml --train --gpu 0 tag=thermos_magic123_final
cd ..

python objectC_single_image_to_3d_package\code\create_objectC_enhanced_thermos.py
```

## Included Code

- `code/prepare_objectC_image.py`: foreground RGBA/mask preparation
- `code/create_objectC_enhanced_thermos.py`: final display mesh generator
- `code/export_magic123_mesh_simple.py`: checkpoint-to-PLY exporter
- `run_configs/objectC-thermos-magic123-lowvram.yaml`: Magic123 low-VRAM config
- `run_configs/parsed.yaml`: parsed config from the completed run
- `code/modified_threestudio_files/`: patched files used for this Windows low-VRAM run
