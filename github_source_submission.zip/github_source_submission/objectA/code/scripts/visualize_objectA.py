from __future__ import annotations

import argparse
import html
import math
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw


REPO_DIR = Path(__file__).resolve().parent / "2d-gaussian-splatting"
if REPO_DIR.exists():
    sys.path.insert(0, str(REPO_DIR))

from arguments import ModelParams, PipelineParams  # noqa: E402
from gaussian_renderer import GaussianModel, render  # noqa: E402
from scene import Scene  # noqa: E402
from utils.general_utils import safe_state  # noqa: E402


def tensor_to_pil(tensor: torch.Tensor) -> Image.Image:
    tensor = torch.clamp(tensor.detach().cpu(), 0.0, 1.0)
    array = (tensor.permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)
    return Image.fromarray(array)


def resize_to_width(image: Image.Image, width: int) -> Image.Image:
    if image.width == width:
        return image
    height = max(1, round(image.height * width / image.width))
    return image.resize((width, height), Image.Resampling.LANCZOS)


def make_pair_image(gt: Image.Image, rendered: Image.Image, label: str) -> Image.Image:
    gap = 12
    label_h = 28
    gt = gt.convert("RGB")
    rendered = rendered.convert("RGB")
    if rendered.size != gt.size:
        rendered = rendered.resize(gt.size, Image.Resampling.LANCZOS)

    canvas = Image.new("RGB", (gt.width * 2 + gap, gt.height + label_h), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((0, 6), f"{label}  input", fill=(20, 20, 20))
    draw.text((gt.width + gap, 6), "2DGS render", fill=(20, 20, 20))
    canvas.paste(gt, (0, label_h))
    canvas.paste(rendered, (gt.width + gap, label_h))
    return canvas


def compute_metrics(rendered: torch.Tensor, gt: torch.Tensor) -> tuple[float, float]:
    rendered = torch.clamp(rendered.detach(), 0.0, 1.0)
    gt = torch.clamp(gt.detach().to(rendered.device), 0.0, 1.0)
    mse = torch.mean((rendered - gt) ** 2).item()
    mae = torch.mean(torch.abs(rendered - gt)).item()
    psnr = 99.0 if mse <= 1e-12 else -10.0 * math.log10(mse)
    return psnr, mae


def make_contact_sheet(pair_paths: list[Path], output_path: Path, thumb_width: int) -> None:
    thumbs = []
    for path in pair_paths:
        image = Image.open(path).convert("RGB")
        thumbs.append(resize_to_width(image, thumb_width))
    if not thumbs:
        return

    cols = min(3, len(thumbs))
    rows = (len(thumbs) + cols - 1) // cols
    gap = 14
    cell_h = max(img.height for img in thumbs)
    sheet = Image.new("RGB", (cols * thumb_width + (cols - 1) * gap, rows * cell_h + (rows - 1) * gap), "white")
    for idx, img in enumerate(thumbs):
        x = (idx % cols) * (thumb_width + gap)
        y = (idx // cols) * (cell_h + gap)
        sheet.paste(img, (x, y))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path, quality=94)


def write_html(output_path: Path, rows: list[dict], title: str) -> None:
    items = []
    for row in rows:
        compare = html.escape(row["compare"].as_posix())
        render_path = html.escape(row["render"].as_posix())
        name = html.escape(row["name"])
        items.append(
            f"""
            <figure>
              <a href="{compare}"><img src="{compare}" alt="{name} comparison"></a>
              <figcaption>
                <strong>{name}</strong><br>
                PSNR {row["psnr"]:.2f} dB · MAE {row["mae"]:.4f}<br>
                <a href="{render_path}">render only</a>
              </figcaption>
            </figure>
            """
        )

    page = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    body {{
      margin: 0;
      font-family: Arial, sans-serif;
      color: #171717;
      background: #f7f7f5;
    }}
    header {{
      padding: 28px 32px 18px;
      background: #ffffff;
      border-bottom: 1px solid #ddd;
    }}
    h1 {{
      margin: 0 0 8px;
      font-size: 24px;
      font-weight: 700;
    }}
    p {{
      margin: 0;
      color: #555;
      line-height: 1.5;
    }}
    main {{
      padding: 24px 32px 40px;
    }}
    .grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 18px;
      align-items: start;
    }}
    figure {{
      margin: 0;
      background: white;
      border: 1px solid #ddd;
      border-radius: 8px;
      overflow: hidden;
    }}
    img {{
      display: block;
      width: 100%;
      height: auto;
      background: white;
    }}
    figcaption {{
      padding: 10px 12px 12px;
      font-size: 13px;
      color: #444;
      line-height: 1.45;
    }}
    a {{
      color: #0b5cad;
    }}
  </style>
</head>
<body>
  <header>
    <h1>{html.escape(title)}</h1>
    <p>Each panel shows the captured input view on the left and the 2DGS render on the right.</p>
  </header>
  <main>
    <section class="grid">
      {"".join(items)}
    </section>
  </main>
</body>
</html>
"""
    output_path.write_text(page, encoding="utf-8")


def write_video(pair_paths: list[Path], output_path: Path, fps: float) -> bool:
    try:
        import cv2
    except ImportError:
        return False

    if not pair_paths:
        return False

    frames = [np.array(Image.open(path).convert("RGB")) for path in pair_paths]
    height = max(frame.shape[0] for frame in frames)
    width = max(frame.shape[1] for frame in frames)
    writer = cv2.VideoWriter(
        str(output_path),
        cv2.VideoWriter_fourcc(*"mp4v"),
        fps,
        (width, height),
    )
    if not writer.isOpened():
        return False

    for frame in frames:
        canvas = np.full((height, width, 3), 255, dtype=np.uint8)
        canvas[: frame.shape[0], : frame.shape[1], :] = frame
        writer.write(cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR))
    writer.release()
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Render Object A 2DGS views for visual comparison.")
    model = ModelParams(parser)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", default=10000, type=int)
    parser.add_argument("--output", default="output/objectA_visualization")
    parser.add_argument("--max_images", default=0, type=int, help="0 means render all train cameras.")
    parser.add_argument("--stride", default=1, type=int)
    parser.add_argument("--thumb_width", default=520, type=int)
    parser.add_argument("--video_fps", default=8.0, type=float)
    parser.add_argument("--no_video", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    if not args.source_path:
        args.source_path = "data/objectA"
    if not args.model_path:
        args.model_path = "output/objectA_2dgs"

    safe_state(args.quiet)
    dataset = model.extract(args)
    pipe = pipeline.extract(args)

    gaussians = GaussianModel(dataset.sh_degree)
    scene = Scene(dataset, gaussians, load_iteration=args.iteration, shuffle=False)
    background = torch.tensor([1, 1, 1] if dataset.white_background else [0, 0, 0], dtype=torch.float32, device="cuda")

    cameras = scene.getTrainCameras()[:: max(1, args.stride)]
    if args.max_images > 0:
        cameras = cameras[: args.max_images]

    output_root = Path(args.output)
    render_dir = output_root / "renders"
    input_dir = output_root / "inputs"
    compare_dir = output_root / "side_by_side"
    for directory in (render_dir, input_dir, compare_dir):
        directory.mkdir(parents=True, exist_ok=True)

    rows = []
    pair_paths = []
    for camera in cameras:
        package = render(camera, gaussians, pipe, background)
        rendered = package["render"]
        gt = camera.original_image
        psnr, mae = compute_metrics(rendered, gt)

        rendered_img = tensor_to_pil(rendered)
        gt_img = tensor_to_pil(gt)
        label = camera.image_name

        render_path = render_dir / f"{label}.png"
        input_path = input_dir / f"{label}.png"
        compare_path = compare_dir / f"{label}.jpg"
        rendered_img.save(render_path)
        gt_img.save(input_path)
        make_pair_image(gt_img, rendered_img, label).save(compare_path, quality=94)

        pair_paths.append(compare_path)
        rows.append(
            {
                "name": label,
                "input": input_path.relative_to(output_root),
                "render": render_path.relative_to(output_root),
                "compare": compare_path.relative_to(output_root),
                "psnr": psnr,
                "mae": mae,
            }
        )

    make_contact_sheet(pair_paths, output_root / "contact_sheet.jpg", args.thumb_width)
    write_html(output_root / "index.html", rows, f"Object A 2DGS visual comparison, iteration {scene.loaded_iter}")
    if not args.no_video:
        write_video(pair_paths, output_root / "side_by_side.mp4", args.video_fps)

    print(f"Rendered {len(rows)} camera views.")
    print(f"Open this in a browser: {output_root / 'index.html'}")
    print(f"Contact sheet: {output_root / 'contact_sheet.jpg'}")
    print(f"Side-by-side frames: {compare_dir}")
    print(f"Video: {output_root / 'side_by_side.mp4'}")


if __name__ == "__main__":
    main()
