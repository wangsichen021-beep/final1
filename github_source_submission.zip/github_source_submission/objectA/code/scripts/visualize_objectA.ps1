$ErrorActionPreference = "Stop"

$Python = "d:\1\envs\deep_learining\python.exe"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

& $Python "$Root\visualize_objectA.py" `
  -s "$Root\data\objectA" `
  -m "$Root\output\objectA_2dgs" `
  --iteration 10000 `
  --output "$Root\output\objectA_visualization" `
  --stride 1 `
  --video_fps 8 `
  --quiet
