from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import pycolmap


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}


def copy_images(source_dir: Path, target_dir: Path) -> list[str]:
    target_dir.mkdir(parents=True, exist_ok=True)
    image_names = []
    for image_path in sorted(source_dir.iterdir()):
        if image_path.suffix.lower() not in IMAGE_EXTENSIONS:
            continue
        target_path = target_dir / image_path.name
        if not target_path.exists() or image_path.stat().st_mtime > target_path.stat().st_mtime:
            shutil.copy2(image_path, target_path)
        image_names.append(image_path.name)
    if not image_names:
        raise RuntimeError(f"No images found in {source_dir}")
    return image_names


def reset_path(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def choose_largest_model(reconstructions: dict[int, pycolmap.Reconstruction]) -> tuple[int, pycolmap.Reconstruction]:
    if not reconstructions:
        raise RuntimeError("COLMAP did not reconstruct any model.")

    def score(item):
        _, reconstruction = item
        return (reconstruction.num_reg_images(), reconstruction.num_points3D())

    return max(reconstructions.items(), key=score)


def main():
    parser = argparse.ArgumentParser(description="Run pycolmap SfM and undistortion for Object A.")
    parser.add_argument("--dataset", default="data/objectA")
    parser.add_argument("--source-images", default=None, help="Defaults to <dataset>/images.")
    parser.add_argument("--camera-model", default="SIMPLE_RADIAL")
    parser.add_argument("--use-gpu", action="store_true")
    parser.add_argument("--reset", action="store_true")
    args = parser.parse_args()

    dataset = Path(args.dataset)
    source_images = Path(args.source_images) if args.source_images else dataset / "images"
    input_dir = dataset / "input"
    distorted_dir = dataset / "distorted"
    database_path = distorted_dir / "database.db"
    sparse_parent = distorted_dir / "sparse"
    best_sparse = distorted_dir / "sparse_best"
    final_sparse_zero = dataset / "sparse" / "0"

    dataset.mkdir(parents=True, exist_ok=True)
    image_names = copy_images(source_images, input_dir)

    if args.reset:
        reset_path(database_path)
        reset_path(sparse_parent)
        reset_path(best_sparse)
        reset_path(dataset / "sparse")

    distorted_dir.mkdir(parents=True, exist_ok=True)
    sparse_parent.mkdir(parents=True, exist_ok=True)

    reader_options = pycolmap.ImageReaderOptions()
    reader_options.camera_model = args.camera_model

    extraction_options = pycolmap.FeatureExtractionOptions()
    extraction_options.use_gpu = bool(args.use_gpu)
    extraction_options.max_image_size = 1600
    extraction_options.sift.max_num_features = 12000
    extraction_options.sift.peak_threshold = 0.004

    matching_options = pycolmap.FeatureMatchingOptions()
    matching_options.use_gpu = bool(args.use_gpu)
    matching_options.guided_matching = True

    mapper_options = pycolmap.IncrementalPipelineOptions()
    mapper_options.multiple_models = True
    mapper_options.min_model_size = max(8, min(20, len(image_names) // 4))
    mapper_options.ba_global_function_tolerance = 1e-6
    mapper_options.mapper.abs_pose_min_num_inliers = 20
    mapper_options.mapper.init_min_num_inliers = 80
    mapper_options.mapper.ba_local_num_images = 8

    print(f"Images: {len(image_names)} in {input_dir}")
    print(f"Database: {database_path}")
    print("Extracting SIFT features...")
    pycolmap.extract_features(
        database_path,
        input_dir,
        camera_mode=pycolmap.CameraMode.SINGLE,
        reader_options=reader_options,
        extraction_options=extraction_options,
    )

    print("Matching image pairs exhaustively...")
    pycolmap.match_exhaustive(database_path, matching_options=matching_options)

    print("Running incremental mapping...")
    reconstructions = pycolmap.incremental_mapping(database_path, input_dir, sparse_parent, options=mapper_options)
    model_id, reconstruction = choose_largest_model(reconstructions)
    print(
        f"Selected model {model_id}: "
        f"{reconstruction.num_reg_images()} registered images, "
        f"{reconstruction.num_points3D()} 3D points"
    )

    reset_path(best_sparse)
    best_sparse.mkdir(parents=True, exist_ok=True)
    reconstruction.write(best_sparse)

    print("Undistorting images to 2DGS/COLMAP layout...")
    pycolmap.undistort_images(
        dataset,
        best_sparse,
        input_dir,
        output_type="COLMAP",
        copy_policy=pycolmap.FileCopyType.copy,
    )

    if not final_sparse_zero.exists() and (dataset / "sparse" / "cameras.bin").exists():
        final_sparse_zero.mkdir(parents=True, exist_ok=True)
        for sparse_file in (dataset / "sparse").glob("*.bin"):
            shutil.copy2(sparse_file, final_sparse_zero / sparse_file.name)

    if not final_sparse_zero.exists():
        raise RuntimeError(f"Expected final sparse model at {final_sparse_zero}, but it was not created.")

    print(f"Done. Final COLMAP dataset: {dataset}")
    print(f"Final sparse model: {final_sparse_zero}")


if __name__ == "__main__":
    main()
