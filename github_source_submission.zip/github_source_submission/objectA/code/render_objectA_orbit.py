from __future__ import annotations

import argparse
import copy
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw


REPO_DIR = Path(__file__).resolve().parent / "2d-gaussian-splatting"
if REPO_DIR.exists():
    sys.path.insert(0, str(REPO_DIR))

from arguments import ModelParams, PipelineParams  # noqa: E402
from gaussian_renderer import GaussianModel, render  # noqa: E402
from scene import Scene  # noqa: E402
from utils.general_utils import safe_state  # noqa: E402


def normalize(x: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(x)
    if norm < 1e-8:
        return x
    return x / norm


def pad_poses(poses: np.ndarray) -> np.ndarray:
    bottom = np.broadcast_to([0, 0, 0, 1.0], poses[..., :1, :4].shape)
    return np.concatenate([poses[..., :3, :4], bottom], axis=-2)


def unpad_poses(poses: np.ndarray) -> np.ndarray:
    return poses[..., :3, :4]


def viewmatrix(lookdir: np.ndarray, up: np.ndarray, position: np.ndarray) -> np.ndarray:
    z_axis = normalize(lookdir)
    x_axis = normalize(np.cross(up, z_axis))
    y_axis = normalize(np.cross(z_axis, x_axis))
    return np.stack([x_axis, y_axis, z_axis, position], axis=1)


def transform_poses_pca(poses: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    centers = poses[:, :3, 3]
    center_mean = centers.mean(axis=0)
    centered = centers - center_mean
    eigval, eigvec = np.linalg.eig(centered.T @ centered)
    order = np.argsort(eigval)[::-1]
    rot = eigvec[:, order].T
    if np.linalg.det(rot) < 0:
        rot = np.diag(np.array([1, 1, -1])) @ rot
    transform = np.concatenate([rot, rot @ -center_mean[:, None]], axis=-1)
    poses_recentered = unpad_poses(transform @ pad_poses(poses))
    transform = np.concatenate([transform, np.eye(4)[3:]], axis=0)
    if poses_recentered.mean(axis=0)[2, 1] < 0:
        poses_recentered = np.diag(np.array([1, -1, -1])) @ poses_recentered
        transform = np.diag(np.array([1, -1, -1, 1])) @ transform
    return poses_recentered, transform


def focus_point(poses: np.ndarray) -> np.ndarray:
    directions = poses[:, :3, 2:3]
    origins = poses[:, :3, 3:4]
    m = np.eye(3) - directions * np.transpose(directions, [0, 2, 1])
    mt_m = np.transpose(m, [0, 2, 1]) @ m
    return np.linalg.inv(mt_m.mean(0)) @ (mt_m @ origins).mean(0)[:, 0]


def generate_orbit_cameras(viewpoint_cameras, n_frames: int, radius_scale: float, z_variation: float):
    c2ws = np.array(
        [np.linalg.inv(np.asarray(cam.world_view_transform.T.detach().cpu().numpy())) for cam in viewpoint_cameras]
    )
    poses = c2ws[:, :3, :] @ np.diag([1, -1, -1, 1])
    poses_recentered, colmap_to_world = transform_poses_pca(poses)

    center = focus_point(poses_recentered)
    camera_centers = poses_recentered[:, :3, 3]
    offset = np.array([center[0], center[1], 0.0])
    spread = np.percentile(np.abs(camera_centers - offset), 90, axis=0) * radius_scale
    spread[0] = max(spread[0], 1e-3)
    spread[1] = max(spread[1], 1e-3)

    z_low, z_high = np.percentile(camera_centers[:, 2], [20, 80])
    avg_up = normalize(poses_recentered[:, :3, 1].mean(0))
    up_axis = int(np.argmax(np.abs(avg_up)))
    up = np.eye(3)[up_axis] * np.sign(avg_up[up_axis])

    new_poses = []
    for theta in np.linspace(0, 2 * np.pi, n_frames, endpoint=False):
        position = np.array(
            [
                center[0] + spread[0] * np.cos(theta),
                center[1] + spread[1] * np.sin(theta),
                z_variation * (z_low + (z_high - z_low) * (np.cos(theta) * 0.5 + 0.5)),
            ]
        )
        new_poses.append(viewmatrix(position - center, up, position))

    new_poses = np.linalg.inv(colmap_to_world) @ pad_poses(np.asarray(new_poses))
    trajectory = []
    base_camera = viewpoint_cameras[0]
    for c2w in new_poses:
        c2w = c2w @ np.diag([1, -1, -1, 1])
        camera = copy.deepcopy(base_camera)
        camera.world_view_transform = torch.from_numpy(np.linalg.inv(c2w).T).float().cuda()
        camera.full_proj_transform = (
            camera.world_view_transform.unsqueeze(0).bmm(camera.projection_matrix.unsqueeze(0))
        ).squeeze(0)
        camera.camera_center = camera.world_view_transform.inverse()[3, :3]
        trajectory.append(camera)
    return trajectory


def tensor_to_uint8(tensor: torch.Tensor) -> np.ndarray:
    image = torch.clamp(tensor.detach().cpu(), 0.0, 1.0)
    return (image.permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)


def save_contact_sheet(frame_paths: list[Path], output_path: Path, columns: int = 6) -> None:
    if not frame_paths:
        return
    selected = [frame_paths[i] for i in np.linspace(0, len(frame_paths) - 1, min(24, len(frame_paths)), dtype=int)]
    thumbs = []
    for path in selected:
        img = Image.open(path).convert("RGB")
        width = 180
        height = max(1, round(img.height * width / img.width))
        thumbs.append(img.resize((width, height), Image.Resampling.LANCZOS))

    gap = 10
    rows = int(np.ceil(len(thumbs) / columns))
    cell_w = thumbs[0].width
    cell_h = thumbs[0].height + 22
    sheet = Image.new("RGB", (columns * cell_w + (columns - 1) * gap, rows * cell_h + (rows - 1) * gap), "white")
    draw = ImageDraw.Draw(sheet)
    for idx, thumb in enumerate(thumbs):
        x = (idx % columns) * (cell_w + gap)
        y = (idx // columns) * (cell_h + gap)
        draw.text((x, y), f"novel {idx + 1:02d}", fill=(20, 20, 20))
        sheet.paste(thumb, (x, y + 22))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path, quality=94)


def write_video(frames: list[np.ndarray], output_path: Path, fps: float) -> None:
    height, width = frames[0].shape[:2]
    writer = cv2.VideoWriter(str(output_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
    if not writer.isOpened():
        raise RuntimeError(f"Could not open video writer: {output_path}")
    for frame in frames:
        writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
    writer.release()


def write_html(output_dir: Path, n_frames: int) -> None:
    html = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Object A 2DGS Novel View Orbit</title>
  <style>
    body {{ margin: 0; font-family: Arial, sans-serif; background: #f6f6f4; color: #171717; }}
    header {{ padding: 24px 28px; background: white; border-bottom: 1px solid #ddd; }}
    main {{ padding: 24px 28px 40px; max-width: 980px; margin: 0 auto; }}
    video, img {{ width: 100%; height: auto; display: block; background: white; border: 1px solid #ddd; }}
    h1 {{ margin: 0 0 8px; font-size: 24px; }}
    p {{ margin: 0; color: #555; line-height: 1.5; }}
    section {{ margin-top: 24px; }}
    a {{ color: #0b5cad; }}
  </style>
</head>
<body>
  <header>
    <h1>Object A 2DGS 新视角环绕渲染</h1>
    <p>这是沿新相机轨迹渲染的 novel view，不是原始输入帧复刻。共 {n_frames} 帧。</p>
  </header>
  <main>
    <section>
      <video controls loop src="orbit.mp4"></video>
    </section>
    <section>
      <p><a href="frames/">查看逐帧 PNG</a></p>
    </section>
    <section>
      <img src="orbit_contact_sheet.jpg" alt="Novel view contact sheet">
    </section>
  </main>
</body>
</html>
"""
    (output_dir / "index.html").write_text(html, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Render a novel-view orbit from the trained Object A 2DGS model.")
    model = ModelParams(parser)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", default=10000, type=int)
    parser.add_argument("--output", default="output/objectA_orbit")
    parser.add_argument("--frames", default=160, type=int)
    parser.add_argument("--fps", default=24.0, type=float)
    parser.add_argument("--radius_scale", default=0.9, type=float)
    parser.add_argument("--z_variation", default=0.18, type=float)
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    if not args.source_path:
        args.source_path = "data/objectA"
    if not args.model_path:
        args.model_path = "output/objectA_2dgs"

    safe_state(args.quiet)
    dataset = model.extract(args)
    pipe = pipeline.extract(args)
    gaussians = GaussianModel(dataset.sh_degree)
    scene = Scene(dataset, gaussians, load_iteration=args.iteration, shuffle=False)
    background = torch.tensor([1, 1, 1] if dataset.white_background else [0, 0, 0], dtype=torch.float32, device="cuda")

    output_dir = Path(args.output)
    frames_dir = output_dir / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)

    cameras = generate_orbit_cameras(scene.getTrainCameras(), args.frames, args.radius_scale, args.z_variation)
    frames = []
    frame_paths = []
    for idx, camera in enumerate(cameras):
        rendered = tensor_to_uint8(render(camera, gaussians, pipe, background)["render"])
        path = frames_dir / f"orbit_{idx:04d}.png"
        Image.fromarray(rendered).save(path)
        frames.append(rendered)
        frame_paths.append(path)

    write_video(frames, output_dir / "orbit.mp4", args.fps)
    save_contact_sheet(frame_paths, output_dir / "orbit_contact_sheet.jpg")
    write_html(output_dir, len(frames))
    print(f"Rendered {len(frames)} novel-view frames.")
    print(f"Open: {output_dir / 'index.html'}")
    print(f"Video: {output_dir / 'orbit.mp4'}")


if __name__ == "__main__":
    main()
