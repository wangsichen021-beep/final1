$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$RenderPython = "d:\1\envs\deep_learining\python.exe"
$MeshPython = "$Root\.venv_2dgs_mesh\Scripts\python.exe"

& $RenderPython "$Root\export_objectA_tsdf_inputs.py" `
  -s "$Root\data\objectA" `
  -m "$Root\output\objectA_2dgs" `
  --iteration 10000 `
  --output "$Root\output\objectA_tsdf_inputs_grabcut" `
  --alpha_threshold 0.05 `
  --mask grabcut `
  --quiet

& $MeshPython "$Root\fuse_objectA_mesh_open3d.py" `
  --input "$Root\output\objectA_tsdf_inputs_grabcut\transforms_tsdf.json" `
  --output "$Root\output\objectA_mesh_grabcut" `
  --depth_trunc 10 `
  --voxel_size 0.02 `
  --sdf_trunc 0.10 `
  --keep_clusters 8 `
  --min_triangles 80

& $MeshPython "$Root\postprocess_objectA_mesh.py" `
  --input "$Root\output\objectA_mesh_grabcut\objectA_mesh_clean.ply" `
  --output "$Root\output\objectA_mesh_grabcut_final" `
  --min_triangles 80
