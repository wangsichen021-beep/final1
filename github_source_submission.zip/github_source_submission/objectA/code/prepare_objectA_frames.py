from __future__ import annotations

import argparse
from pathlib import Path

import cv2


def sharpness(gray):
    return cv2.Laplacian(gray, cv2.CV_64F).var()


def resize_to_max_side(image, max_side):
    height, width = image.shape[:2]
    longest = max(height, width)
    if longest <= max_side:
        return image

    scale = max_side / float(longest)
    new_size = (round(width * scale), round(height * scale))
    return cv2.resize(image, new_size, interpolation=cv2.INTER_AREA)


def main():
    parser = argparse.ArgumentParser(description="Extract sharp, evenly-spaced frames from the Object A video.")
    parser.add_argument("--video", default="物体A.mp4")
    parser.add_argument("--dataset", default="data/objectA")
    parser.add_argument("--frames", type=int, default=72)
    parser.add_argument("--max-side", type=int, default=960)
    parser.add_argument("--samples-per-bin", type=int, default=5)
    args = parser.parse_args()

    video_path = Path(args.video)
    dataset_path = Path(args.dataset)
    image_dir = dataset_path / "images"
    image_dir.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {video_path}")

    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    if frame_count <= 0:
        raise RuntimeError("Video reports no frames.")

    for old_frame in image_dir.glob("frame_*.jpg"):
        old_frame.unlink()

    usable_start = max(0, int(frame_count * 0.02))
    usable_end = min(frame_count - 1, int(frame_count * 0.98))
    span = max(1, usable_end - usable_start)
    frames_to_write = min(args.frames, span)

    saved = []
    for out_idx in range(frames_to_write):
        bin_start = usable_start + int(out_idx * span / frames_to_write)
        bin_end = usable_start + int((out_idx + 1) * span / frames_to_write)
        if bin_end <= bin_start:
            bin_end = bin_start + 1

        candidates = []
        sample_count = max(1, args.samples_per_bin)
        for sample_idx in range(sample_count):
            alpha = (sample_idx + 0.5) / sample_count
            frame_idx = min(frame_count - 1, bin_start + int((bin_end - bin_start) * alpha))
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
            ok, frame = cap.read()
            if not ok:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            candidates.append((sharpness(gray), frame_idx, frame))

        if not candidates:
            continue

        _, frame_idx, best_frame = max(candidates, key=lambda item: item[0])
        best_frame = resize_to_max_side(best_frame, args.max_side)
        output_path = image_dir / f"frame_{out_idx:04d}.jpg"
        cv2.imwrite(str(output_path), best_frame, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
        saved.append((output_path.name, frame_idx))

    cap.release()

    if not saved:
        raise RuntimeError("No frames were extracted.")

    height, width = cv2.imread(str(image_dir / saved[0][0])).shape[:2]
    print(f"Video: {video_path} ({frame_count} frames, {fps:.2f} fps)")
    print(f"Saved {len(saved)} frames to {image_dir} at {width}x{height}")
    print(f"First source frame: {saved[0][1]}, last source frame: {saved[-1][1]}")


if __name__ == "__main__":
    main()
