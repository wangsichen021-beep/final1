$ErrorActionPreference = "Stop"

$Python = "d:\1\envs\deep_learining\python.exe"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

& $Python "$Root\render_objectA_orbit.py" `
  -s "$Root\data\objectA" `
  -m "$Root\output\objectA_2dgs" `
  --iteration 10000 `
  --output "$Root\output\objectA_orbit" `
  --frames 160 `
  --fps 24 `
  --radius_scale 0.9 `
  --z_variation 0.18 `
  --quiet
