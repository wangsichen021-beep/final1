from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import torch
import torchvision
from PIL import Image, ImageDraw

REPO_DIR = Path(__file__).resolve().parent / "2d-gaussian-splatting"
if REPO_DIR.exists():
    sys.path.insert(0, str(REPO_DIR))

from arguments import ModelParams, PipelineParams
from gaussian_renderer import GaussianModel, render
from scene import Scene
from utils.general_utils import safe_state


def save_tensor_image(tensor, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torchvision.utils.save_image(torch.clamp(tensor, 0.0, 1.0), str(path))


def make_contact_sheet(gt_paths, render_paths, output_path: Path, thumb_width=180) -> None:
    pairs = []
    for gt_path, render_path in zip(gt_paths, render_paths):
        gt = Image.open(gt_path).convert("RGB")
        rd = Image.open(render_path).convert("RGB")
        scale = thumb_width / gt.width
        size = (thumb_width, max(1, round(gt.height * scale)))
        pairs.append((gt.resize(size, Image.Resampling.LANCZOS), rd.resize(size, Image.Resampling.LANCZOS)))

    if not pairs:
        return

    label_h = 24
    gap = 12
    cols = min(4, len(pairs))
    rows = (len(pairs) + cols - 1) // cols
    cell_w = thumb_width * 2 + gap
    cell_h = pairs[0][0].height + label_h
    sheet = Image.new("RGB", (cols * cell_w + (cols - 1) * gap, rows * cell_h + (rows - 1) * gap), "white")
    draw = ImageDraw.Draw(sheet)

    for idx, (gt, rd) in enumerate(pairs):
        col = idx % cols
        row = idx // cols
        x = col * (cell_w + gap)
        y = row * (cell_h + gap)
        draw.text((x, y), "input", fill=(20, 20, 20))
        draw.text((x + thumb_width + gap, y), "2DGS", fill=(20, 20, 20))
        sheet.paste(gt, (x, y + label_h))
        sheet.paste(rd, (x + thumb_width + gap, y + label_h))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path, quality=95)


def main():
    parser = argparse.ArgumentParser(description="Render a lightweight 2DGS preview without Open3D.")
    model = ModelParams(parser)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", default=-1, type=int)
    parser.add_argument("--output", default="")
    parser.add_argument("--max_images", default=16, type=int)
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    safe_state(args.quiet)
    dataset = model.extract(args)
    pipe = pipeline.extract(args)

    gaussians = GaussianModel(dataset.sh_degree)
    scene = Scene(dataset, gaussians, load_iteration=args.iteration, shuffle=False)
    bg_color = [1, 1, 1] if dataset.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")

    output_root = Path(args.output) if args.output else Path(args.model_path) / "preview" / f"ours_{scene.loaded_iter}"
    render_dir = output_root / "renders"
    gt_dir = output_root / "ground_truth"

    cameras = scene.getTrainCameras()
    if args.max_images > 0:
        stride = max(1, len(cameras) // args.max_images)
        cameras = cameras[::stride][: args.max_images]

    gt_paths = []
    render_paths = []
    for camera in cameras:
        package = render(camera, gaussians, pipe, background)
        render_path = render_dir / f"{camera.image_name}.png"
        gt_path = gt_dir / f"{camera.image_name}.png"
        save_tensor_image(package["render"], render_path)
        save_tensor_image(camera.original_image, gt_path)
        render_paths.append(render_path)
        gt_paths.append(gt_path)

    contact_sheet = output_root / "contact_sheet.jpg"
    make_contact_sheet(gt_paths, render_paths, contact_sheet)
    print(f"Rendered {len(render_paths)} preview views to {output_root}")
    print(f"Contact sheet: {contact_sheet}")


if __name__ == "__main__":
    main()
