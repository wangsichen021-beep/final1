# Object A 2DGS Reconstruction Package

这是“物体 A 真实多视角重建”的汇总交付文件夹，包含复现实验所需代码、输入数据样本、COLMAP 位姿、2DGS 结果、环绕渲染和 mesh 结果。

## 文件夹结构

- `code/`
  - 复现脚本
  - `2d-gaussian-splatting/` 轻量源码副本
- `data_sample/`
  - `物体A.mp4` 原始手机视频
  - `objectA_images/` 已抽取的 72 张输入帧
- `results/`
  - `2dgs_model/point_cloud.ply` 最终 2DGS Gaussian PLY
  - `2dgs_model/cameras.json` 相机文件
  - `colmap/sparse_0/` COLMAP 位姿与稀疏点
  - `orbit/orbit.mp4` 新视角环绕视频
  - `mesh/` 推荐 mesh 版本
  - `visual_comparison/` 输入视角左右对比
- `reports/`
  - 原始过程报告、mesh 报告和最终总览 HTML
- `env/`
  - 依赖版本记录

## 最推荐查看的结果

1. 新视角环绕视频：
   - `results/orbit/orbit.mp4`

2. 最终 2DGS Gaussian 模型：
   - `results/2dgs_model/point_cloud.ply`

3. 推荐 mesh：
   - 快速打开：`results/mesh/largest_100k.ply`
   - 细节更多：`results/mesh/largest.ply`
   - 保留更多断开部件：`results/mesh/top6_100k.ply`

4. mesh 预览：
   - `results/mesh/largest_preview.jpg`
   - `results/mesh/top6_preview.jpg`

## 复现环境

本次实际运行使用两个环境：

- 2DGS 训练/渲染：`d:\1\envs\deep_learining`
- Open3D mesh 融合：项目根目录的 `.venv_2dgs_mesh`，Python 3.11 + Open3D 0.19.0

依赖记录：

- `env/deep_learining_pip_freeze.txt`
- `env/mesh_py311_pip_freeze.txt`

注意：原工作区的 `2d-gaussian-splatting/submodules/` 是空目录，2DGS CUDA 扩展来自已安装好的 `deep_learining` 环境。如果要在新机器从零复现，需要先按 2DGS 官方说明补齐并安装 `diff-surfel-rasterization` 和 `simple-knn`。

## 从原始视频复现主要流程

以下命令假设在原工作区 `C:\Users\王司晨\Desktop\1` 运行。若在本交付包内运行，请根据相对路径调整输入输出位置。

```powershell
python code\prepare_objectA_frames.py --video data_sample\物体A.mp4 --dataset data\objectA --frames 72 --max-side 960
& 'd:\1\envs\deep_learining\python.exe' code\run_pycolmap_objectA.py --dataset data\objectA --reset
cd code\2d-gaussian-splatting
& 'd:\1\envs\deep_learining\python.exe' train.py -s ..\..\data\objectA -m ..\..\output\objectA_2dgs --iterations 10000 --save_iterations 7000 10000 --test_iterations 7000 10000 --quiet
```

## 从已有结果重新生成可视化

```powershell
& 'd:\1\envs\deep_learining\python.exe' code\render_objectA_orbit.py -s data\objectA -m output\objectA_2dgs --iteration 10000 --output output\objectA_orbit --frames 160 --fps 24 --quiet
& 'd:\1\envs\deep_learining\python.exe' code\visualize_objectA.py -s data\objectA -m output\objectA_2dgs --iteration 10000 --output output\objectA_visualization --quiet
```

## 从已有 2DGS 模型重新导出 mesh

```powershell
& 'd:\1\envs\deep_learining\python.exe' code\export_objectA_tsdf_inputs.py -s data\objectA -m output\objectA_2dgs --iteration 10000 --output output\objectA_tsdf_inputs_grabcut --alpha_threshold 0.05 --mask grabcut --quiet
.\.venv_2dgs_mesh\Scripts\python.exe code\fuse_objectA_mesh_open3d.py --input output\objectA_tsdf_inputs_grabcut\transforms_tsdf.json --output output\objectA_mesh_grabcut --depth_trunc 10 --voxel_size 0.02 --sdf_trunc 0.10 --keep_clusters 8 --min_triangles 80
.\.venv_2dgs_mesh\Scripts\python.exe code\postprocess_objectA_mesh.py --input output\objectA_mesh_grabcut\objectA_mesh_clean.ply --output output\objectA_mesh_grabcut_final --min_triangles 80
```

## 结果质量说明

2DGS 的新视角渲染能体现物体的三维结构；mesh 是基于 2DGS 渲染深度做 TSDF 融合得到的三角网格近似。由于原视频没有物体级 mask，背景和桌面仍可能进入部分 mesh，`largest_100k.ply` 是最适合快速查看和提交展示的版本。
